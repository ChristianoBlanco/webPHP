<?php
$recebe_get = $this->id_ativ_gd;

//SQL para passar o funcion�rio agregado a atividade que foi cadastrado.
$sql_r = mysql_query("SELECT * FROM tb_atividade WHERE id_ativ = '$this->id_ativ'");
$sql_r_row = mysql_fetch_array($sql_r);
$recup_id_func = $sql_r_row["id_func"];
$recup_id_func;

$this->sql_upd = "UPDATE tb_atividade_gd SET 
id_ativ='$this->id_ativ', 
id_func='$recup_id_func', 
id_sem='$this->id_sem',
hora_ini='$this->hora_ini',
hora_fim='$this->hora_fim'
WHERE id_ativ_gd='$recebe_get' "    
?>