<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_conn_lider = "mysql03.grlider.com.br";
$database_conn_lider = "grlider4";
$username_conn_lider = "grlider4";
$password_conn_lider = "costa2costa";
$conn_lider = mysql_connect($hostname_conn_lider, $username_conn_lider, $password_conn_lider) or trigger_error(mysql_error(),E_USER_ERROR); 
$db = mysql_select_db("grlider4", $conn_lider);
?>