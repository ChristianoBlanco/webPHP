<?php

$this->sql_ins = "INSERT INTO tb_func (id_func, nome_func, dt_nas, sexo, prof, nivel_prof, status_prof, cpf, id, org_exp, end, bairro, cidade, cep, tel, cel, email, obs, dt_cri) 
VALUES 
(
'',
'$this->nome_func',
'$this->dt_nas',
'$this->sexo',
'$this->prof',
'$this->nivel_prof',
'$this->status_prof',
'$this->cpf',
'$this->id',
'$this->org_exp',
'$this->ende',
'$this->bairro',
'$this->cidade',
'$this->cep',
'$this->tel',
'$this->cel',
'$this->email',
'$this->obs',
'$this->dt_cri')"    
?>