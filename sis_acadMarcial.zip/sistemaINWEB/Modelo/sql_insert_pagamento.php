<?php

$this->sql_ins = "INSERT INTO tb_pagamento (id_pg, id_alu, mat_alu, status_pg, dt_venc, dt_pag, multa, valor_t) 
VALUES 
(
'',
'$this->id_alu',
'$this->mat_alu',
'$this->status_pg',
'$this->dt_venc',
'$this->dt_pag',
'$this->multa',
'$this->valor_t')"    
?>