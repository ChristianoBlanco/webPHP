<?php

$recebe_get = @$_GET["id_usu"];
$se_existe->sql_conf = "SELECT * FROM tb_usuario WHERE id_usu = '$recebe_get'";    

?>