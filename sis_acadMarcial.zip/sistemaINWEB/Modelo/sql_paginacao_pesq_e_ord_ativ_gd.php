<?php
    //COLOCA EM ORDE CRESCENTE OU DECRESCENTE OS ITENS DO GRID
    if(($_GET["t_ord"])<> "G.id_sem"){	 
     $_SESSION["ordena"] = $_GET['t_ord'];
     //$_SESSION["ordem"]         = $_GET['ord'];
     //$paginacao->sql = "select * from tb_atividade_gd A, tb_atividade T, tb_func F where A.id_ativ = T.id_ativ AND A.id_ativ = $_SESSION[ordena] ";	//seleção completa
	
	 $paginacao->sql ="SELECT G.id_ativ_gd, G.id_sem, G.hora_ini, G.hora_fim, G.id_func,A.nome_ativ,
       F.nome_func, F.id_func
FROM tb_atividade A  INNER JOIN tb_atividade_gd  G ON(G.id_ativ = A.id_ativ)
                     INNER JOIN tb_func F ON(G.id_func = F.id_func) WHERE G.id_ativ = $_SESSION[ordena]";
    }else{ 
      $_SESSION["ordena"] = "G.id_sem";
	  $_SESSION["ordenap"] = "id_sem";
     //$_SESSION["ordem"]         = "asc"; 	 
     $paginacao->sql = "SELECT G.id_ativ_gd, G.id_sem, G.hora_ini, G.hora_fim, G.id_func,A.nome_ativ,
       F.nome_func, F.id_func
FROM tb_atividade A  INNER JOIN tb_atividade_gd  G ON(G.id_ativ = A.id_ativ)
                     INNER JOIN tb_func F ON(G.id_func = F.id_func) order by $_SESSION[ordena] ASC ";	//seleção completa
    } 

?>