<?php
    //COLOCA EM ORDE CRESCENTE OU DECRESCENTE OS ITENS DO GRID
    if(isset($_GET["t_ord"])){	 
     $_SESSION["ordena"] = $_GET['t_ord'];
     //$_SESSION["ordem"]         = $_GET['ord'];
     $paginacao->sql = "select * from tb_aluno order by $_SESSION[ordena] ";	//seleção completa
    }else{ 
     $_SESSION["ordena"] = "id_aluno asc";
     //$_SESSION["ordem"]         = "asc"; 	 
     $paginacao->sql = "select * from tb_aluno order by $_SESSION[ordena] ";	//seleção completa
    } 
    if(isset($_GET["t_ord_pesq"]) and isset($_GET["t_like_pesq"])){	 

    $_SESSION["ord_pesq"] = $_GET['t_ord_pesq'];
    	
	$_SESSION["like"]     = $_GET['t_like_pesq'];
	
    $_SESSION["ordena"]   = "id_aluno asc"; 	 
    $paginacao->sql = "select * from tb_aluno where $_SESSION[ord_pesq] like '%$_SESSION[like]%' order by $_SESSION[ordena] ";
    }

?>