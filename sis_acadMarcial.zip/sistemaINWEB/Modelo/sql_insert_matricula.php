<?php

$this->sql_ins = "INSERT INTO tb_matricula (id_mat, mat_alu, id_alu, dt_insc, status_pl) 
VALUES 
(
'',
'$this->mat_alu',
'$this->id_alu',
'$this->dt_insc',
'$this->status_pl',
'$this->situacao')"    
?>