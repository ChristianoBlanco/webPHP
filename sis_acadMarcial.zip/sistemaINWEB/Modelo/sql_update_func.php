<?php
$recebe_get = $this->id_func;

$this->nome_func;

$this->sql_upd = "UPDATE tb_func SET 
nome_func='$this->nome_func', 
dt_nas='$this->dt_nas', 
sexo='$this->sexo', 
prof='$this->prof',
nivel_prof='$this->nivel_prof',
status_prof='$this->status_prof',
cpf='$this->cpf',
id='$this->id',
org_exp='$this->org_exp',
end='$this->ende',
bairro='$this->bairro',
cidade='$this->cidade',
cep='$this->cep',
tel='$this->tel',
cel='$this->cel',
email='$this->email',
obs='$this->obs',
dt_cri='$this->dt_cri'  
WHERE id_func='$recebe_get' "    
?>