<?php
$recebe_get = $this->id_usu;

$this->nome_usu;

$this->sql_upd = "UPDATE tb_usuario SET nome_usu='$this->nome_usu', login='$this->login', senha='$this->senha', nivel_ac='$this->nivel_ac' 
                  WHERE id_usu='$recebe_get' "    
?>