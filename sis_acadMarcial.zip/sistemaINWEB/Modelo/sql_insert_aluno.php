<?php

$this->sql_ins = "INSERT INTO tb_aluno (id_aluno, nome_alu, dt_nas, sexo, cpf, id, org_exp, resp_nome_alu, resp_cpf, resp_id, resp_org_exp, end, bairro, cidade, cep, tel, cel, email, obs, dt_cri) 
VALUES 
(
'',
'$this->nome_alu',
'$this->dt_nas',
'$this->sexo',
'$this->cpf',
'$this->id',
'$this->org_exp',
'$this->resp_nome_alu',
'$this->resp_cpf',
'$this->resp_id',
'$this->resp_org_exp',
'$this->ende',
'$this->bairro',
'$this->cidade',
'$this->cep',
'$this->tel',
'$this->cel',
'$this->email',
'$this->obs',
'$this->dt_cri')"    

?>