<?php

$recebe_get = @$_GET["id_aluno"];
$se_existe->sql_conf = "SELECT * FROM tb_aluno WHERE id_aluno = '$recebe_get'";    

?>