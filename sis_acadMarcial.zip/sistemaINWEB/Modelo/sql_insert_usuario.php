<?php

$this->sql_ins = "INSERT INTO tb_usuario (id_usu, dt_usu, nome_usu, login, senha, nivel_ac) VALUES ('','$this->dt_usu','$this->nome_usu','$this->login','$this->senha', '$this->nivel_ac')"    

?>