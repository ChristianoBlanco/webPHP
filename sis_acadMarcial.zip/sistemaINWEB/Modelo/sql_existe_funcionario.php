<?php

$recebe_get = @$_GET["id_func"];
$se_existe->sql_conf = "SELECT * FROM tb_func WHERE id_func = '$recebe_get'";    

?>