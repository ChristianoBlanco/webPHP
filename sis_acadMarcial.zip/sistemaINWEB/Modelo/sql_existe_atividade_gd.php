<?php

$recebe_get = @$_GET["id_ativ_gd"];
$se_existe->sql_conf = "SELECT * FROM tb_atividade_gd G, tb_atividade A WHERE G.id_ativ_gd = '$recebe_get' and G.id_func = A.id_func";    

?>