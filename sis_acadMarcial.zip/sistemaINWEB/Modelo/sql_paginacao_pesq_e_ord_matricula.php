<?php
    //COLOCA EM ORDE CRESCENTE OU DECRESCENTE OS ITENS DO GRID
    if(isset($_GET["t_ord"])){	 
     $_SESSION["ordena"] = $_GET['t_ord'];
     //$_SESSION["ordem"]         = $_GET['ord'];
     $paginacao->sql = "select * from tb_matricula order by $_SESSION[ordena] ";	//seleção completa
	//$paginacao->sql = "SELECT M.id_mat, M.mat_alu, M.id_alu, M.dt_insc, M.status_pl , P.id_alu, P.mat_alu, P.status_pg FROM tb_matricula M INNER JOIN  tb_pagamento P ON M.id_alu = P.id_alu ORDER BY $_SESSION[ordena]";
    }else{ 
     $_SESSION["ordena"] = "id_alu asc";
     //$_SESSION["ordem"]         = "asc"; 	 
     $paginacao->sql = "select * from tb_matricula order by $_SESSION[ordena] ";	//seleção completa
	//$paginacao->sql = "SELECT M.id_mat, M.mat_alu, M.id_alu, M.dt_insc, M.status_pl , P.id_alu, P.mat_alu, P.status_pg FROM tb_matricula M INNER JOIN  tb_pagamento P ON M.mat_alu = P.mat_alu ORDER BY $_SESSION[ordena]";
    } 
    if(isset($_GET["t_ord_pesq"]) and isset($_GET["t_like_pesq"])){	 
      
	  if( $_GET["t_ord_pesq"] == "nome_alu"){ 
	      
		   $_SESSION["like"]     = converte_id($_GET['t_like_pesq']);
		   $_SESSION["ord_pesq"] = "id_alu";
		   $_SESSION["ordena"]   = "id_alu asc"; 	
		   $paginacao->sql = "select * from tb_matricula where $_SESSION[ord_pesq] like '%$_SESSION[like]%' order by $_SESSION[ordena] ";
		   //$paginacao->sql = "M.id_mat, M.mat_alu, M.id_alu, M.dt_insc, M.status_pl , P.id_alu, P.mat_alu, P.status_pg FROM tb_matricula A INNER JOIN  tb_pagamento P ON M.mat_alu = P.mat_alu WHERE $_SESSION[ord_pesq] like '%$_SESSION[like]%' order by $_SESSION[ordena]";
	   }else{
	       $_SESSION["ord_pesq"] = $_GET['t_ord_pesq'];
    	
	       $_SESSION["like"]     = $_GET['t_like_pesq'];
	
           $_SESSION["ordena"]   = "id_alu asc"; 	 
           $paginacao->sql = "select * from tb_matricula where $_SESSION[ord_pesq] like '%$_SESSION[like]&' order by $_SESSION[ordena] ";
		   //$paginacao->sql = "M.id_mat, M.mat_alu, M.id_alu, M.dt_insc, M.status_pl , P.id_alu, P.mat_alu, P.status_pg FROM tb_matricula A INNER JOIN  tb_pagamento P ON M.mat_alu = P.mat_alu WHERE $_SESSION[ord_pesq] like '%$_SESSION[like]%' order by $_SESSION[ordena]";
	    }
    }

?>