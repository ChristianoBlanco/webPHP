<?php
    //COLOCA EM ORDE CRESCENTE OU DECRESCENTE OS ITENS DO GRID
    if(isset($_GET["t_ord"])){	 
     $_SESSION["ordena"] = $_GET['t_ord'];
     //$_SESSION["ordem"]         = $_GET['ord'];
     $paginacao->sql = "select * from tb_matricula order by $_SESSION[ordena] ";	//seleção completa
    }else{ 
     $_SESSION["ordena"] = "id_mat asc";
     //$_SESSION["ordem"]         = "asc"; 	 
     $paginacao->sql = "select * from tb_matricula order by $_SESSION[ordena] ";	//seleção completa
    } 

?>