<?php
//SQL para passar o funcion�rio agregado a atividade que foi cadastrado.
$sql_r = mysql_query("SELECT * FROM tb_atividade WHERE id_ativ = '$this->id_ativ'");
$sql_r_row = mysql_fetch_array($sql_r);
$recup_id_func = $sql_r_row["id_func"];
$recup_id_func;

$this->sql_ins = "INSERT INTO tb_atividade_gd (id_ativ_gd, id_ativ, id_func, id_sem, hora_ini, hora_fim) 
VALUES 
(
'',
'$this->id_ativ',
'$recup_id_func',
'$this->id_sem',
'$this->hora_ini',
'$this->hora_fim')"    
?>