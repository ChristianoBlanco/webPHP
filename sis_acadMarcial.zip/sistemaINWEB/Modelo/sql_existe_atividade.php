<?php

$recebe_get = @$_GET["id_ativ"];
$se_existe->sql_conf = "SELECT * FROM tb_atividade A, tb_func F WHERE A.id_ativ = '$recebe_get' and A.id_func = F.id_func";    

?>