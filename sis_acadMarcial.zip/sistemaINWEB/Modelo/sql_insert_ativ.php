<?php

$this->sql_ins = "INSERT INTO tb_atividade (id_ativ, nome_ativ, id_func, valor, status_pl) 
VALUES 
(
'',
'$this->nome_ativ',
'$this->id_func',
'$this->valor',
'$this->status_pl')"    
?>