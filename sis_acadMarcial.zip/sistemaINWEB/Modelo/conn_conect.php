<?php
error_reporting (E_ALL & ~ E_NOTICE & ~ E_DEPRECATED);
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_conn_user = "localhost";
//$database_conn_user = "innweb";
$username_conn_user = "root";
$password_conn_user = "";
$conexao = mysql_pconnect($hostname_conn_user, $username_conn_user, $password_conn_user) or trigger_error(mysql_error(),E_USER_ERROR); 
mysql_select_db("innweb", $conexao);
?>