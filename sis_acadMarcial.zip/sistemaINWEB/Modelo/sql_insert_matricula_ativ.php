﻿<?php

$this->sql_ins = "INSERT INTO tb_matricula_ativ (id_mat_ativ, mat_alu, id_ativ, valor_ativ, desconto, valor_p)
VALUES 
(
'',
'$this->mat_alu',
'$this->id_ativ',
'$this->valor_ativ',
'$this->desc',
'$this->valor_p')"    
?>