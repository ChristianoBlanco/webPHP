<?php


$recebe_get = @$_SESSION["login"];
$se_existe->sql_conf = "SELECT * FROM tb_usuario WHERE login = '$recebe_get'";    

?>