<?php
$recebe_get = $this->id_ativ;

//$this->nome_func;

$this->sql_upd = "UPDATE tb_atividade SET 
nome_ativ='$this->nome_ativ', 
id_func='$this->id_func', 
valor='$this->valor',
status_pl='$this->status_pl'
WHERE id_ativ='$recebe_get' "    
?>