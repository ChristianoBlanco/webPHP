<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_conn_lider = "localhost";
//$database_conn_lider = "grlider4";
$username_conn_lider = "root";
$password_conn_lider = "";
$conn_lider = mysql_pconnect($hostname_conn_lider, $username_conn_lider, $password_conn_lider) or trigger_error(mysql_error(),E_USER_ERROR);
mysql_select_db("gr_intranet_lider", $conn_lider); 
?>