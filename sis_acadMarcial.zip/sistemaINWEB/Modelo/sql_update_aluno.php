<?php
$recebe_get = $this->id_aluno;

$this->nome_usu;

$this->sql_upd = "UPDATE tb_aluno SET 
nome_alu='$this->nome_alu', 
dt_nas='$this->dt_nas', 
sexo='$this->sexo', 
cpf='$this->cpf',
id='$this->id',
org_exp='$this->org_exp',
resp_nome_alu='$this->resp_nome_alu',
resp_cpf='$this->resp_cpf',
resp_id='$this->resp_id',
resp_org_exp='$this->resp_org_exp',
end='$this->ende',
bairro='$this->bairro',
cidade='$this->cidade',
cep='$this->cep',
tel='$this->tel',
cel='$this->cel',
email='$this->email',
obs='$this->obs',
dt_cri='$this->dt_cri',
mat_alu='$this->mat_alu'  
WHERE id_aluno='$recebe_get' "    
?>