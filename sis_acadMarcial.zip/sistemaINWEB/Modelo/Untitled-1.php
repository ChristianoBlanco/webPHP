﻿ <?php	
	     //Limpa os campos se carregados pós aleração
		   include("func_convert_data.php");
		   if(empty($_GET["id_ativ_gd"]))
		   {
			//$_SESSION["id_ativ_gd"] = ""; 
			$_SESSION["id_ativ"]    = ""; 
			$_SESSION["id_func"]    = ""; 
			$_SESSION["id_sem"]     = "";
			$_SESSION["hora_ini"]   = "";	
			$_SESSION["hora_fim"]   = "";	
			$_SESSION["titulo_tb"]  = "INCLUSÃO DE GRADE DE ATIVIDADES";  
		   }
		   ?>
           <?php 
		   include("func_select_option.php");
		   include("../Controle/class_se_existe.php");
		   $se_existe = new se_existe();
		   include("../Modelo/sql_existe_atividade_gd.php");
           $se_existe->se_existe_ativ_gd();
		   
           if(isset($se_existe->res_conf["id_ativ_gd"]))
		   {
			 
			$_SESSION["id_ativ_gd"] = $se_existe->res_conf["id_ativ_gd"]; 
			$_SESSION["id_ativ"]    = $se_existe->res_conf["id_ativ"]; 
			$_SESSION["id_func"]    = $se_existe->res_conf["id_func"];
			$_SESSION["id_sem"]     = $se_existe->res_conf["id_sem"]; 
			$_SESSION["hora_ini"]   = $se_existe->res_conf["hora_ini"];
			$_SESSION["hora_fim"]   = $se_existe->res_conf["hora_fim"];
			$_SESSION["titulo_tb"]  = "ALTERAÇÃO DE GRADE DE ATIVIDADE";  
		   }
		   ?>
        <form name="form1" action="../Controle/class_add_ativ_gd.php" enctype="multipart/form-data" method="post">
        <input type="hidden" name="t_id_ativ_gd" value="<?php echo $_SESSION["id_ativ_gd"]; ?>" size="12" maxlength="10" />
        <table width="850" border="0" >
         <tr>
         <td style="font-weight:bold;"><?php echo $_SESSION["titulo_tb"]; ?></td>
         <td align="right">
         <?php echo @$_SESSION["msg"]; @$_SESSION["msg"] = "";?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         <a href="../Visao/index.php?active4=active&page=3&fun=14" target="_parent">
         <img src="../Visao/images/buttons/Sair_over.png" width="26" height="26" title= "Voltar"></a>
         </td>
         </tr>
        </table>
        <br/>
        <table width="500" class="table table-striped table-bordered">
         <tr>
         
         <td>Atividade:<br /><select name="t_id_ativ" required>
         <option value="<?php echo $_SESSION["id_ativ"]; ?>" 
         selected="selected" style="font-weight:bold; text-decoration:underline;"><?php echo $_SESSION["nome_ativ"]; ?></option>
         
         <?php 
		   $sql = mysql_query("SELECT * FROM tb_atividade");
			while ($row_1= mysql_fetch_array($sql)) {
             $sid_ativ   = $row_1['id_ativ'];
			 $snome_aviv = $row_1['nome_ativ'];
             echo"<option value='$sid_ativ'>$snome_ativ</option>";
			}
		 ?>
         </select>
         </td>
         <td>
         Professor: <br /><select name="t_id_func" required>
         <?php 
		   $sql = mysql_query("SELECT * FROM tb_func");
			while ($row_1= mysql_fetch_array($sql)) {
             $sid_func   = $row_1['id_func'];
			 $snome_func = $row_1['nome_func'];
             echo"<option value='$sid_func'>$snome_func</option>";
			 if($_SESSION["id_func"] == "$sid_func"){$_SESSION["nome_func"] = "$snome_func"}
			}
		 ?>
         <option value="<?php echo $_SESSION["id_func"]; ?>" 
         selected="selected" style="font-weight:bold; text-decoration:underline;"><?php echo $_SESSION["nome_func"]; ?></option>
         </select>
         </td>
         <td>Semana:
         <br />
         <select name="t_id_sem" required>
         <?php 
		   $sql = mysql_query("SELECT * FROM tb_sem");
			while ($row_1= mysql_fetch_array($sql)) {
             $sid_sem   = $row_1['id_sem'];
			 $snome_sem = $row_1['nome_sem'];
             echo"<option value='$sid_sem'>$snome_sem</option>";
			 if($_SESSION["id_sem"] == "$sid_sem"){$_SESSION["nome_sem"] = "$snome_sem"}
			}
		 ?>
         <option value="<?php echo $_SESSION["id_sem"]; ?>" 
         selected="selected" style="font-weight:bold; text-decoration:underline;"><?php echo $_SESSION["nome_sem"]; ?></option>
         </select>
         </td>
         </tr>
         
         <tr>
         <td>
         Hora inicio:<br/>
         <input type="text" name="t_hora_ini" size="10" value="<?php echo $_SESSION["hora_ini"]; ?>" />
         </td>
         <td>
         Hora fim:<br/>
         <input type="text" name="t_hora_fim" size="10" value="<?php echo $_SESSION["hora_fim"]; ?>" />
         </td>
         <td>
         &nbsp;
         </td>
         </tr>
        </table>
        <br />
        
        <table width="850" border="0" >
         <tr>
         <td>
         <button type="submit" class="templatemo-blue-button width-10" name="bt_func_grava" onclick="return confirm('Confirma os dados?')"/>
         Gravar</button>
         </td>
         <td width="273" style="color:#F00;">&nbsp;
	     
          </td>
          </tr>
        </table>