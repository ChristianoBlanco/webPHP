<?php
    

	//COLOCA EM ORDEM DE PESQUISA
    if(isset($_GET["t_ord"])){
     $_SESSION["ordena"] = $_GET['t_ord'];
     //$_SESSION["ordem"]         = $_GET['ord'];
    // $paginacao->sql = "select * from tb_aluno order by $_SESSION[ordena] ";	//seleção completa
	$paginacao->sql = "SELECT * FROM tb_pagamento $_SESSION[ordena]";
    }else{ 
     $_SESSION["ordena"] = "WHERE status_pg='I' ORDER BY id_alu asc";
     //$_SESSION["ordem"]         = "asc"; 	 
     //$paginacao->sql = "select * from tb_aluno order by $_SESSION[ordena] ";	//seleção completa
	 $paginacao->sql = "SELECT * FROM tb_pagamento $_SESSION[ordena]";
    } 
	


if(isset($_GET["t_ord_pesq"]) and isset($_GET["t_like_pesq"])){	 
	
	include("func_convert_id_aluno.php");
	
	$_SESSION["ord_pesq"] = $_GET['t_ord_pesq'];
	$_SESSION["like"]     = $_GET['t_like_pesq'];
    $_SESSION["ordena"]   = "id_alu asc"; 	 
     //$paginacao->sql = "select * from tb_aluno where $_SESSION[ord_pesq] like '%$_SESSION[like]%' order by $_SESSION[ordena]";
	
	$paginacao->sql = "SELECT * FROM tb_pagamento WHERE status_pg='T' and $_SESSION[ord_pesq] like '%$_SESSION[like]%' order by $_SESSION[ordena]";
	 
}

?>