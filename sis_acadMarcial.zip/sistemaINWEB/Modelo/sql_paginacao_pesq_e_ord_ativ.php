<?php
    //COLOCA EM ORDE CRESCENTE OU DECRESCENTE OS ITENS DO GRID
    if(isset($_GET["t_ord"])){	 
     $_SESSION["ordena"] = $_GET['t_ord'];
     //$_SESSION["ordem"]         = $_GET['ord'];
     $paginacao->sql = "select * from tb_atividade A, tb_func F where A.id_func = F.id_func order by $_SESSION[ordena] ";	//seleção completa
    }else{ 
     $_SESSION["ordena"] = "id_ativ asc";
     //$_SESSION["ordem"]         = "asc"; 	 
     $paginacao->sql = "select * from tb_atividade A, tb_func F where A.id_func = F.id_func  order by $_SESSION[ordena] ";	//seleção completa
    } 

?>