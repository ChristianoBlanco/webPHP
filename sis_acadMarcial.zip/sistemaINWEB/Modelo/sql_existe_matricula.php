<?php

$recebe_get = @$_GET["id_mat"];
$se_existe->sql_conf = "SELECT * FROM tb_matricula WHERE id_mat = '$recebe_get'";    

?>