<?php 
//Sql de consulta para Login de usuários
$SQL = "SELECT * FROM tb_usuario WHERE login = '$login' ";
?>