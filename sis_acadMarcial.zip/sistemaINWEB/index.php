<?php
print "<meta HTTP-EQUIV='Refresh' CONTENT='0;URL=visao/login.php'>";
?>