<nav class="templatemo-top-nav col-lg-12 col-md-12">
  <ul class="text-uppercase">
    <li><a href="index.php?active1=active&page=0&fun=0" class="<?php echo @$_GET["active1"] ?> ">Admin</a></li>
    <li><a href="index.php?active2=active&page=1&fun=8"class="<?php echo @$_GET["active2"] ?> ">Alunos</a></li>
    <li><a href="index.php?active3=active&page=2&fun=11"class="<?php echo @$_GET["active3"] ?> ">Funcionários</a></li>
    <li><a href="index.php?active4=active&page=3&fun=14"class="<?php echo @$_GET["active4"] ?> ">Atividades</a></li>
    <li><a href="index.php?active5=active&page=4&fun=18"class="<?php echo @$_GET["active5"] ?> ">Matrículas</a></li>
    <!--li><a href="login.php">Sair</a></li-->
  </ul>
</nav> 

