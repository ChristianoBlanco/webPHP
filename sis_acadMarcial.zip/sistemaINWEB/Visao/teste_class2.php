<?php
session_start();
include("../Modelo/conn_conect.php");
include("../Controle/func_convert_data.php");
include("../Controle/class_pagina.php");

?>
<?php

//Chamo a classe
$paginacao = new paginacao();
$paginacao->qtn = 6;// determina a quantidade de elementos na barra de navegação
$paginacao->ttpg = 6;// total de registros por página
$paginacao->pg = @$_GET["pg"];

//COLOCA EM ORDE CRESCENTE OU DECRESCENTE OS ITENS DO GRID
if(isset($_GET["t_ord"])){	 
 $_SESSION["ordena"] = @$_GET['t_ord'];
 //$_SESSION["ordem"]         = $_GET['ord'];
 $paginacao->sql = "select * from tb_usuario order by $_SESSION[ordena] ";	//seleção completa
 }else{ 
 $_SESSION["ordena"] = "id_usu asc";
 //$_SESSION["ordem"]         = "asc"; 	 
 $paginacao->sql = "select * from tb_usuario order by $_SESSION[ordena] ";	//seleção completa
 } 
?>

<!-- Inicio tabela-->
<table width="98%" cellpadding="0" cellspacing="0" id="box-table-a" summary="Employee Pay Sheet" style="margin-left:10px;">
<thead>
<tr>
<th width="11%"  scope="col"><?php  print utf8_decode("Id"); ?></th>
<th width="25%" scope="col"><div style="margin-left:0px;"><?php  print utf8_decode("Usuário"); ?></div></th>
<th width="41%" scope="col" ><div style="margin-left:0px;"><?php print utf8_decode("Nível"); ?></div></th>
<th width="12%" scope="col" ><?php print utf8_decode("Data inclusão"); ?></th>
<th width="11%" scope="col" ><div style="margin-left:25px;"><?php print utf8_decode("Excluir"); ?></div></th>
</tr>
</thead>
<tbody>
<?php
//Mostra resultados
$paginacao->config_paginacao();
while($row = mysql_fetch_array($paginacao->limite)){
?>
<tr>
<td width="11%" height="19">&nbsp;<a href="index_internet_informativo.php?conn_web=web&sel=1&num_doc=<?php print $row["id_usu"]; ?>"><?php print $row["id_usu"]; ?></a>
</td>
<td width="25%"><?php print $row["nome_usu"]; ?></td>
<td width="41%"><?php print $row["nivel_ac"]; ?></td>
<td width="12%"><?php print databr($row["dt_usu"]); ?></td>
<td width="11%" align="center"><a href="sql_web.php?conn_web=web&acao=del_informativo&titulo=<?php print $row["nome_usu"]; ?>&cod=<?php echo $row["id_usu"]; ?>" onclick="return confirm('Deseja excluir este informativo?')"><img src="../images/buttons/Delete_over.png" width="14" height="14"></a>
</td>
</tr>
<?php 
}
?>
<tbody>	
</table>
<!-- fim tabela -->

<?php
//AQUI COMEÇA A BARRA DE NEVEGAÇAO
$paginacao_barra = new paginacao();
$paginacao_barra->paginador_barra();
?>