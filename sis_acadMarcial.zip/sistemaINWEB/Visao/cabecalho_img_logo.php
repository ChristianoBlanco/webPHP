<div class="profile-photo-container">
  <img src="images/profile-photo.jpg" alt="Profile Photo" class="img-responsive">  
  <div class="profile-photo-overlay"></div>
</div>      