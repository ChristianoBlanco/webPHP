<?php 
session_start();
//error_reporting(0);

include("../Modelo/conn_conect.php"); //Conexão com o banco local ou de Intranet.
 
include("../Controle/restrito.php"); //Include de restrição de acesso as páginas.
 ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">  
    <?php include("../Controle/seletor_titulo_cabecalho.php"); ?> 
	<meta name="description" content="">
    <meta name="author" content="templatemo">
    <!-- 
    Visual Admin Template
    http://www.templatemo.com/preview/templatemo_455_visual_admin
    -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,700' rel='stylesheet' type='text/css'>
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/templatemo-style.css" rel="stylesheet">
     
	<script type="text/javascript" src="js/jquery-1.4.2.js"></script>
    <script type='text/javascript' src="js/jquery.autocomplete.js"></script>
    
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style type="text/css" media="screen">
     #SCROLL {
     color:#000000; 
      
     width:900px; 
     height:100px; 
     overflow:auto; 
     }
	</style> 


     
              
      
  </head>
