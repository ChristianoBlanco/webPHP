<footer class="text-right">
            <p>Copyright &copy; 2016 InWeb 
            | Designed by <a href="#" target="_parent">C.Blanco</a></p>
</footer>    