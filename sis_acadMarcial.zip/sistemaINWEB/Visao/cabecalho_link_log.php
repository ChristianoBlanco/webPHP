<header class="templatemo-site-header">
  <!--div class="square"></div -->
  <h1>InWeb - Marcial</h1>
  <div style="margin:1px 0px 0px 4px; color:#FF0;">Bem vindo(a): <?php echo @$_SESSION["login"]; ?></div>
  <div><a href="../Controle/fechar.php" style="margin:1px 0px 0px 4px; color:#FFF;" target="_parent">&raquo;&raquo;&nbsp;Sair</a></div>
</header>
