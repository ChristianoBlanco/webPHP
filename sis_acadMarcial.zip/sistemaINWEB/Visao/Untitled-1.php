﻿ <?php
		   //Limpa os campos se carregados pós aleração
		   include("func_convert_data.php");
		   if(empty($_GET["id_ativ"]))
		   {
			$_SESSION["id_ativ"]    = ""; 
			$_SESSION["nome_ativ"]  = ""; 
			$_SESSION["id_func"]     = ""; 
			$_SESSION["valor"]       = "";		
			$_SESSION["titulo_tb"]     = "INCLUSÃO DE ATIVIDADES";  
		   }
		   ?>
           <?php 
		   include("func_select_option.php");
		   include("../Controle/class_se_existe.php");
		   $se_existe = new se_existe();
		   include("../Modelo/sql_existe_atividade.php");
           $se_existe->se_existe_ativ();
		   
           if(isset($se_existe->res_conf["id_func"]))
		   {
			 
			$_SESSION["id_ativ"]     = $se_existe->res_conf["id_ativ"]; 
			$_SESSION["nome_ativ"]   = $se_existe->res_conf["nome_ativ"];
			$_SESSION["id_func"]      = $se_existe->res_conf["id_func"]; 
			$_SESSION["valor"]        = $se_existe->res_conf["valor"];
			$_SESSION["titulo_tb"]   = "ALTERAÇÃO DE ATIVIDADE";  
		   }
		   ?>
        <form name="form1" action="../Controle/class_add_ativ.php" enctype="multipart/form-data" method="post">
        <input type="hidden" name="t_id_ativ" value="<?php echo $_SESSION["id_ativ"]; ?>" size="12" maxlength="10" />
        <table width="850" border="0" >
         <tr>
         <td style="font-weight:bold;"><?php echo $_SESSION["titulo_tb"]; ?></td>
         <td align="right">
         <?php echo @$_SESSION["msg"]; @$_SESSION["msg"] = "";?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         <a href="../Visao/index.php?active4=active&page=3&fun=14" target="_parent">
         <img src="../Visao/images/buttons/Sair_over.png" width="26" height="26" title= "Voltar"></a></td>
         </tr>
        </table>
        <br/>
        <table width="500" class="table table-striped table-bordered">
         <tr>
         <td>Atividade:<br /><input type="texto" name="t_nome_ativ" value="<?php echo $_SESSION["nome_ativ"]; ?>" size="40" maxlength="60" 
         required="required" />
         </td>
         <td>Valor<br /><input type="texto" name="t_valor_ativ" value="<?php echo $_SESSION["valor"]; ?>" size="12" maxlength="10" 
         required="required" onkeypress="return formatar_moeda(this,',','.',event);"   />
         </td>
         </tr>
         <tr>
         <td>Professor:<br />
         <select name="t_id_func" required>
         <option value="<?php echo $_SESSION["id_func"]; ?>" 
         selected="selected" style="font-weight:bold; text-decoration:underline;"><?php echo $_SESSION["nome_func"]; ?></option>
         
         <?php 
		   $sql = mysql_query("SELECT * FROM tb_func");
			while ($row_1= mysql_fetch_array($sql)) {
             $sid_func   = $row_1['id_func'];
			 $snome_func = $row_1['nome_func'];
             echo"<option value='$sid_func'>$snome_func</option>";
			}
		 ?>
         </select>
         </td>
         <td>&nbsp;
         
         </td>
         </tr>
        </table>
        <br />
        <table width="850" border="0" >
         <tr>
         <td>
         <button type="submit" class="templatemo-blue-button width-10" name="bt_func_grava" onclick="return confirm('Confirma os dados?')"/>
         Gravar</button>
         </td>
         <td width="273" style="color:#F00;">&nbsp;
	     
          </td>
          </tr>
        </table>