-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 28-Abr-2017 às 21:02
-- Versão do servidor: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `innweb`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Extraindo dados da tabela `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2016_09_08_180205_postagem', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `postagens`
--

CREATE TABLE IF NOT EXISTS `postagens` (
  `id_postagem` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `titulo` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `conteudo` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id_postagem`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_aluno`
--

CREATE TABLE IF NOT EXISTS `tb_aluno` (
  `id_aluno` int(11) NOT NULL AUTO_INCREMENT,
  `nome_alu` varchar(60) COLLATE latin1_general_ci NOT NULL,
  `dt_nas` date NOT NULL,
  `sexo` varchar(2) COLLATE latin1_general_ci NOT NULL,
  `cpf` varchar(14) COLLATE latin1_general_ci NOT NULL,
  `id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `org_exp` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `resp_nome_alu` varchar(60) COLLATE latin1_general_ci NOT NULL,
  `resp_cpf` varchar(14) COLLATE latin1_general_ci NOT NULL,
  `resp_id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `resp_org_exp` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `end` varchar(60) COLLATE latin1_general_ci NOT NULL,
  `bairro` varchar(40) COLLATE latin1_general_ci NOT NULL,
  `cidade` varchar(40) COLLATE latin1_general_ci NOT NULL,
  `cep` varchar(9) COLLATE latin1_general_ci NOT NULL,
  `tel` varchar(14) COLLATE latin1_general_ci NOT NULL,
  `cel` varchar(14) COLLATE latin1_general_ci NOT NULL,
  `email` varchar(60) COLLATE latin1_general_ci NOT NULL,
  `obs` text COLLATE latin1_general_ci NOT NULL,
  `dt_cri` date NOT NULL,
  `mat_alu` varchar(15) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_aluno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=9 ;

--
-- Extraindo dados da tabela `tb_aluno`
--

INSERT INTO `tb_aluno` (`id_aluno`, `nome_alu`, `dt_nas`, `sexo`, `cpf`, `id`, `org_exp`, `resp_nome_alu`, `resp_cpf`, `resp_id`, `resp_org_exp`, `end`, `bairro`, `cidade`, `cep`, `tel`, `cel`, `email`, `obs`, `dt_cri`, `mat_alu`) VALUES
(1, 'JoÃ£o da Silva', '1982-10-05', 'M', '09000090989', '112223456', 'IFP', '', '', '', '', 'Rua do Teste 1234 ap 201', 'Centro', 'Rio de Janeiro', '22112-020', '212344-0094', '2199219-0982', 'joao@gmail.com', 'isso Ã© mais um teste de inclusÃ£o diretamente pelo banco de dados Ã§Ã§~Ã§', '2016-01-18', ''),
(2, 'Maria da Silva', '2000-08-01', 'F', '', '', '', 'Fulana da Silva', '098.222.123.07', '1233445544 ', 'DETRAN-RJ', 'Rua do ABCD Casa 01', 'Vila da Penha', 'Rio de Janeiro', '221121-02', '212345-9945', '2198576-0927', 'maria@hotmail.com', '', '2016-01-18', '1602'),
(3, 'Fred', '0000-00-00', 'h', 'kjklkj', 'kljkjkl', 'kljkljkl', 'kljkjkl', 'kljklj', 'kljkljl', 'kljkl', 'ljkljlkjklghjkgh', 'hghjghjgg', 'gfgtdgdfg', 'ytrtd', 'fhgfhg', 'ghfghf', '', 'gfghfghfdgd', '0000-00-00', ''),
(4, 'Alberto Paz de Oliveira', '0000-00-00', 'g', 'ghfghf', 'gfghfhg', 'ghfghf', 'ghfghf', 'fghgfhg', 'ghfghfghf', 'ghfghfgh', 'fghfgh', 'ghfghfghf', 'fghfghfh', 'ghfghfg', 'fghfgh', 'ghfghfhg', '', 'gfhgfghgh', '0000-00-00', ''),
(5, 'Fluminense', '0000-00-00', 'M', '092222176-09', '112345678', 'IFP', '', '', '', '', 'Rua Alvaro Chaves 1500', 'Laranjeiras', 'Rio de Janeiro', '21222-060', '(21)2560-9912', '(21)98718-0918', 'flu@fluminense.com.br', 'tests testessssssssssssss ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â£o ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§a , olÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¡', '0000-00-00', '1603'),
(6, 'Teste', '0000-00-00', 'f', '0909009090', '890980989', 'ifp', '', '', '', '', 'rua do teste', 'teste', 'rio de janeiro', '8908998', '9890890', '9890809', '9089080990890', '908908908', '0000-00-00', '908908'),
(7, 'Carlos', '0000-00-00', 'M', '123.335.213-91', 'M', 'IFP', '', '', '', '', 'Rua Novo Teste 21 ap 101', 'Vila da Penha', 'Rio de Janeiro', '21213-060', '(21)2344-0098', '(21)92928-0928', 'carlorj@globo.com', 'OlÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¡ mais um teste feito agora ', '0000-00-00', '1604'),
(8, 'Ryu', '1981-10-10', 'M', '09999887668', '123445670', 'IFP', 'Teste', '09900987760', '112343561', 'Detran-RJ', 'Rua lÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¡ ÃƒÆ’Ã†â€™Ãƒâ', 'Centro', 'Rio de Janeiro', '21222-060', '(21)2233-4409', '(21)99119-8990', 'teste@teste.com.br', 'observaÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â£o de testes , que sÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â£o somente testes', '0000-00-00', '1605');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_atividade`
--

CREATE TABLE IF NOT EXISTS `tb_atividade` (
  `id_ativ` int(11) NOT NULL AUTO_INCREMENT,
  `nome_ativ` varchar(60) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `id_func` int(11) NOT NULL,
  `valor` decimal(10,2) NOT NULL,
  `status_pl` varchar(4) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_ativ`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Extraindo dados da tabela `tb_atividade`
--

INSERT INTO `tb_atividade` (`id_ativ`, `nome_ativ`, `id_func`, `valor`, `status_pl`) VALUES
(1, 'AIKIDO', 1, '70.00', 'MEN'),
(2, 'KRAV MAGA', 2, '70.00', 'MEN'),
(3, 'TAEKWONDO', 3, '70.00', ''),
(4, 'BOXE', 4, '70.00', 'MEN'),
(5, '01- AKIDO TRIMESTRAL', 1, '210.00', 'TRI'),
(6, 'P1 - PACOTE TRIMESTRAL', 2, '300.00', 'TRI');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_atividade_gd`
--

CREATE TABLE IF NOT EXISTS `tb_atividade_gd` (
  `id_ativ_gd` int(11) NOT NULL AUTO_INCREMENT,
  `id_ativ` int(11) NOT NULL,
  `id_func` int(11) NOT NULL,
  `id_sem` int(11) NOT NULL,
  `hora_ini` time NOT NULL,
  `hora_fim` time NOT NULL,
  PRIMARY KEY (`id_ativ_gd`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_func`
--

CREATE TABLE IF NOT EXISTS `tb_func` (
  `id_func` int(11) NOT NULL AUTO_INCREMENT,
  `nome_func` varchar(60) COLLATE latin1_general_ci NOT NULL,
  `dt_nas` date NOT NULL,
  `sexo` varchar(2) COLLATE latin1_general_ci NOT NULL,
  `prof` varchar(40) COLLATE latin1_general_ci NOT NULL,
  `nivel_prof` varchar(40) COLLATE latin1_general_ci NOT NULL,
  `status_prof` varchar(2) COLLATE latin1_general_ci NOT NULL,
  `cpf` varchar(14) COLLATE latin1_general_ci NOT NULL,
  `id` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `org_exp` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `end` varchar(60) COLLATE latin1_general_ci NOT NULL,
  `bairro` varchar(40) COLLATE latin1_general_ci NOT NULL,
  `cidade` varchar(40) COLLATE latin1_general_ci NOT NULL,
  `cep` varchar(9) COLLATE latin1_general_ci NOT NULL,
  `tel` varchar(14) COLLATE latin1_general_ci NOT NULL,
  `cel` varchar(14) COLLATE latin1_general_ci NOT NULL,
  `email` varchar(60) COLLATE latin1_general_ci NOT NULL,
  `obs` text COLLATE latin1_general_ci NOT NULL,
  `dt_cri` date NOT NULL,
  PRIMARY KEY (`id_func`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=5 ;

--
-- Extraindo dados da tabela `tb_func`
--

INSERT INTO `tb_func` (`id_func`, `nome_func`, `dt_nas`, `sexo`, `prof`, `nivel_prof`, `status_prof`, `cpf`, `id`, `org_exp`, `end`, `bairro`, `cidade`, `cep`, `tel`, `cel`, `email`, `obs`, `dt_cri`) VALUES
(1, 'Teste da Silva', '1970-01-25', 'M', 'Ed FÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ', '4', 'C', '99099918999', '112344567', 'IFP', 'Rua abcd do teste 232 casa 1', 'Centro', 'Rio de Janeiro', '21112-030', '(21)2223-9918', '(21)99827-0909', 'teste_rj@hotmail.com', 'testes ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â§ ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¡ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¡ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¡', '2016-01-25'),
(2, 'Maria', '1981-04-15', 'F', 'Contabilidade', '4', 'C', '09988827609', '112334569', 'DETRAN-RJ', 'Rua um dois tres quatro ap 202', 'Ipanema', 'Rio de Janeiro', '21222-030', '(21)2280-8383', '(21)88191-8756', 'mm@teste.com.br', 'testes ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¯ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¿ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â½ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¯ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¿ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â½ ~~~~ ^^', '2016-01-02'),
(4, 'JoÃ£o da silva sauro', '1977-10-10', 'M', 'Contador', '2', 'C', '08233516709', '112343529', 'ifp', 'Rua do teste 123456', 'Olaria', 'Rio de Janeiro', '21215-050', '(21)3884-3839', '(21)93909-9068', 'testejoao@teste.com.br', 'Isso Ã© um  teste de preenchimento de banco de dados mais Ã§Ã§Ã§Ã§', '0000-00-00');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_matricula`
--

CREATE TABLE IF NOT EXISTS `tb_matricula` (
  `id_mat` int(11) NOT NULL AUTO_INCREMENT,
  `mat_alu` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `id_alu` int(11) NOT NULL,
  `dt_insc` date NOT NULL,
  `status_pl` varchar(3) COLLATE latin1_general_ci NOT NULL,
  `situacao` varchar(3) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_mat`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=6 ;

--
-- Extraindo dados da tabela `tb_matricula`
--

INSERT INTO `tb_matricula` (`id_mat`, `mat_alu`, `id_alu`, `dt_insc`, `status_pl`, `situacao`) VALUES
(2, '174-836', 4, '2017-04-08', 'AVU', 'I'),
(3, '174-810', 7, '2017-04-08', 'MEN', 'A'),
(4, '174-894', 7, '2017-04-08', 'TRI', 'A'),
(5, '174-1138', 5, '2017-04-10', 'MEN', 'A');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_matricula_ativ`
--

CREATE TABLE IF NOT EXISTS `tb_matricula_ativ` (
  `id_mat_ativ` int(11) NOT NULL AUTO_INCREMENT,
  `mat_alu` varchar(10) NOT NULL,
  `id_ativ` int(11) NOT NULL,
  `valor_ativ` decimal(10,2) NOT NULL,
  `desconto` decimal(10,2) NOT NULL,
  `valor_p` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id_mat_ativ`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Extraindo dados da tabela `tb_matricula_ativ`
--

INSERT INTO `tb_matricula_ativ` (`id_mat_ativ`, `mat_alu`, `id_ativ`, `valor_ativ`, `desconto`, `valor_p`) VALUES
(5, '174-810', 4, '70.00', '0.00', '70.00'),
(6, '174-810', 1, '70.00', '0.00', '70.00'),
(7, '174-810', 2, '70.00', '0.00', '70.00'),
(8, '174-810', 1, '70.00', '0.00', '70.00'),
(9, '174-810', 1, '70.00', '0.00', '70.00'),
(10, '174-836', 1, '0.00', '0.00', '20.00'),
(11, '174-836', 4, '0.00', '0.00', '20.00'),
(12, '174-810', 4, '70.00', '0.00', '70.00'),
(13, '174-836', 1, '0.00', '0.00', '20.00'),
(14, '174-810', 2, '70.00', '10.00', '60.00'),
(15, '174-894', 5, '210.00', '0.00', '210.00'),
(16, '174-1138', 1, '70.00', '0.00', '70.00'),
(17, '174-894', 6, '300.00', '0.00', '300.00');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_pagamento`
--

CREATE TABLE IF NOT EXISTS `tb_pagamento` (
  `id_pg` int(11) NOT NULL AUTO_INCREMENT,
  `id_alu` int(11) NOT NULL,
  `mat_alu` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `status_pg` varchar(3) COLLATE latin1_general_ci NOT NULL,
  `dt_venc` date NOT NULL,
  `dt_pag` date NOT NULL,
  `multa` decimal(10,2) NOT NULL,
  `valor_t` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id_pg`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=14 ;

--
-- Extraindo dados da tabela `tb_pagamento`
--

INSERT INTO `tb_pagamento` (`id_pg`, `id_alu`, `mat_alu`, `status_pg`, `dt_venc`, `dt_pag`, `multa`, `valor_t`) VALUES
(8, 5, '174-1138', 'P', '2017-04-13', '2017-04-13', '0.00', '70.00'),
(9, 5, '174-1138', 'A', '2017-05-13', '0000-00-00', '0.00', '70.00'),
(10, 7, '174-810', 'P', '2017-04-27', '2017-04-27', '0.00', '480.00'),
(11, 7, '174-810', 'A', '2017-05-27', '0000-00-00', '0.00', '480.00'),
(12, 7, '174-894', 'P', '2017-03-27', '2017-03-27', '0.00', '510.00'),
(13, 7, '174-894', 'A', '2017-04-27', '0000-00-00', '0.00', '510.00');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_sem`
--

CREATE TABLE IF NOT EXISTS `tb_sem` (
  `id_sem` int(11) NOT NULL AUTO_INCREMENT,
  `nome_sem` varchar(10) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_sem`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=8 ;

--
-- Extraindo dados da tabela `tb_sem`
--

INSERT INTO `tb_sem` (`id_sem`, `nome_sem`) VALUES
(1, 'segunda'),
(2, 'terÃƒÆ’Ã‚Â'),
(3, 'quarta'),
(4, 'quinta'),
(5, 'sexta'),
(6, 'sabado'),
(7, 'domingo');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_usuario`
--

CREATE TABLE IF NOT EXISTS `tb_usuario` (
  `id_usu` int(11) NOT NULL AUTO_INCREMENT,
  `dt_usu` date NOT NULL,
  `nome_usu` varchar(60) COLLATE latin1_general_ci NOT NULL,
  `login` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `senha` varchar(80) COLLATE latin1_general_ci NOT NULL,
  `nivel_ac` int(11) NOT NULL,
  PRIMARY KEY (`id_usu`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=17 ;

--
-- Extraindo dados da tabela `tb_usuario`
--

INSERT INTO `tb_usuario` (`id_usu`, `dt_usu`, `nome_usu`, `login`, `senha`, `nivel_ac`) VALUES
(1, '2015-12-10', 'Admin', 'admin', '21232f297a57a5a743894a0e4a801fc3', 3),
(2, '2015-12-10', 'Christiano Blanco', 'blanco', '21232f297a57a5a743894a0e4a801fc3', 3),
(3, '2015-12-10', 'Teste da Silva', 'Teste', 'c3284d0f94606de1fd2af172aba15bf3', 1),
(4, '2015-12-10', 'Usuario 2', 'usuario', 'e10adc3949ba59abbe56e057f20f883e', 2),
(5, '2015-12-10', 'Usuario', 'paz', 'e10adc3949ba59abbe56e057f20f883e', 0),
(6, '2015-12-15', 'Fluminense F. C.', 'Flu', '68c7f78d53fc6cb65ba5aae6f44c4036', 1),
(7, '2015-12-15', 'BÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¡rbara', 'babi', 'e10adc3949ba59abbe56e057f20f883e', 2),
(10, '0000-00-00', 'JoÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â£o do Brasil', 'Silva', 'e10adc3949ba59abbe56e057f20f883e', 2),
(11, '0000-00-00', 'Jose silva', 'jsjs', 'e10adc3949ba59abbe56e057f20f883e', 1),
(12, '0000-00-00', 'AntÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â´nio', 'Attt', 'e10adc3949ba59abbe56e057f20f883e', 1),
(13, '0000-00-00', 'JoÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â£o segundo', 'JJ', 'e10adc3949ba59abbe56e057f20f883e', 3),
(14, '2016-01-13', 'Carlos', 'carlos', 'e10adc3949ba59abbe56e057f20f883e', 3),
(15, '2016-01-14', 'b', 'b', '14e1b600b1fd579f47433b88e8d85291', 3),
(16, '2016-01-14', 'x', 'x', '81dc9bdb52d04dc20036dbd8313ed055', 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tmp_tb_matricula`
--

CREATE TABLE IF NOT EXISTS `tmp_tb_matricula` (
  `id_mat` int(11) NOT NULL AUTO_INCREMENT,
  `mat_alu` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `id_alu` int(11) NOT NULL,
  `status_pg` varchar(2) COLLATE latin1_general_ci NOT NULL,
  `dt_insc` date NOT NULL,
  `dt_venc` date NOT NULL,
  `dt_pag` date NOT NULL,
  `status_alu` varchar(2) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_mat`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
