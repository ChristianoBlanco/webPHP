﻿<?php 
 	 
	 
	<form name='form3' action='../Controle/class_add_pagamento.php' method='post'  enctype='multipart/form-data'>
				 <input type='text' name='t_status_pl' value='$_GET[t_sel]' />
				 <input type='hidden' name='t_mat_alu'  value='$_SESSION[mat_alu]' />				
                 <input type='hidden' name='t_id_alu'   value='$_SESSION[id_alu]' />
                 <input type='hidden' name='t_status_pg'   value='P' />
                 <input type='hidden' name='t_dt_venc'  value='";echo date('d/m/Y');echo"' />
                 <input type='hidden' name='t_dt_pag'   value='";echo date('d/m/Y');echo"' />
                 <input type='hidden' name='t_multa'    value='' />
                 <input type='hidden' name='t_valor_t'  value='$rowSoma[valor_p]' />
				 <input type='submit' name='bt_inc2' value='Ativar pagamento de matricula' style='color:#F00; font-weight:bold;' />
				</form>
				
?>				
				
	<b>Atividades selecionadas:</b><br/><br/>
                <table width='500' border='0' cellspacing='0' cellpadding='0' class='table table-striped table-bordered'>
                <tr>
                <td width='358'>Atividade</td>
                <td width='124'>Valor</td>
                <td width='126'>Desc.</td>
                <td width='125'>Valor parc.</td>
                </tr>
				</table>
				<table width='500' border='0' cellspacing='0' cellpadding='0' class='table table-striped table-bordered'>
                <?php $sql3    = mysql_query("SELECT * FROM tb_matricula_ativ WHERE mat_alu = '$_SESSION[mat_alu]'");
				$sqlSoma = mysql_query("SELECT SUM(valor_p) as valor_p , mat_alu FROM tb_matricula_ativ WHERE mat_alu = '$_SESSION[mat_alu]'"); 
				while($row3 = mysql_fetch_array($sql3)){ ?>
				<tr>
                <td width='358'><?php echo converte_nome_ativ($row3["id_ativ"]); ?></td>
                <td width='124'><?php echo R$&nbsp;$row3["valor_ativ"]; ?></td>
                <td width='126'><?php R$&nbsp;$row3["desconto"]; ?></td>
                <td width='125'><?php R$&nbsp;$row3["valor_p"]; ?></td>
				</tr>
                <?php } ?>
                </table>
                <table width='500' border='0' cellspacing='0' cellpadding='0' class='table table-striped table-bordered'>
                <tr align='right'>
                <td><?php echo "Valor total:<br/>R$&nbsp;".
				$rowSoma = mysql_fetch_array($sqlSoma); ?>
				<?php echo "<font color='#FF0000'>".$rowSoma["valor_p"]."</font>"; ?>
				</td>
                </tr>	
                </table>			