<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php 
session_start();
include("func_convert_data.php");
include("../Modelo/conn_conect.php"); //Conexão com o banco local ou de Intranet.


class add 
{

var $id_usu, $dt_usu, $nome_usu, $login, $senha, $nivel_ac, $ins, $upd, $del, $sel, $sql_ins, $res_ins, $sql_upd, $res_upd;

   
   
   function inserir_matricula()
   {
	  include("../Modelo/sql_insert_matricula.php");
	  $this->ins = mysql_query($this->sql_ins);
	  
	  //Passa matricula para a etapa de matricular atividades
	  $_SESSION["passa_matricula"] = $this->mat_alu;
	  //Passa nome do aluno atraves do id para etapa de matricular atividades
	  $this->idDoAluno = $this->id_alu;
	  $this->sql_conv_id = mysql_query("SELECT id_aluno, nome_alu FROM tb_aluno WHERE id_aluno = $this->idDoAluno ");
	  $this->row_conv_id = mysql_fetch_array($this->sql_conv_id);
	  $_SESSION["passa_nomeAluno"] = $this->row_conv_id["nome_alu"];
	  $_SESSION["passa_idAluno"]   = $this->row_conv_id["id_aluno"];
	  
	  $_SESSION["msg"] = "<font color='#0066FF'>"."Matrícula INSERIDA com sucesso!"."</font>"; //Mensagem exibição para a pagina 
      print "<meta HTTP-EQUIV='Refresh' CONTENT='0;URL=../Visao/index.php?active5=active&page=4&fun=17&t_sel=$this->status_pl'>";
   }
   
   function selecionar_ativ()
   {
   
   }
   
   function alterar_ativ()
   {
	include("../Modelo/sql_update_ativ.php"); 
    $this->upd = mysql_query($this->sql_upd) or die('Erro:' . mysql_error());
	$_SESSION["msg"] = "<font color='#0066FF'>"."Atividade ALTERADA com Sucesso!"."</font>"; //Mensagem exibição para a pagina 
    print "<meta HTTP-EQUIV='Refresh' CONTENT='0;URL=../Visao/index.php?active4=active&page=3&fun=13&id_ativ=$recebe_get'>";
   }

   function deletar_ativ()
   {
   
   }

}
$add = new add();
//Variável que recebe a id do usuário pelo _POST do form, que recebe através do primeiro $recebe_get que é igual a _GET da url 
$recebe_post = $_POST["t_id_mat"];


if($recebe_post <> ""){
   
	//FUNÇÃO GERADORA DE MATRICULA
	//include("func_geramat.php");
    $add->mat_alu   = $_POST["t_mat_alu"];//vai receber da funcao gerador de matriculas
    $add->id_alu    = $_POST["t_id_alu"];
	$add->dt_insc   = datasql($_POST["t_dt_insc"]);
    $add->status_pl = $_POST["t_status_pl"]; //vai receber valor do form de status de matricula
	$add->situacao  = $_POST["situacao"];

 $add->alterar_matriucla();
 //echo "senha OK";
}
if($recebe_post == ""){
    //FUNÇÃO GERADORA DE MATRICULA
	include("func_geramat.php");
    $add->mat_alu   = $geraMat;//vai receber da funcao gerador de matriculas	
    $add->id_alu    = $_POST["t_id_alu"];
    $add->dt_insc   = datasql($_POST["t_dt_insc"]);
    $add->status_pl = $_POST["t_status_pl"];
	$add->situacao  = $_POST["situacao"];

$add->inserir_matricula();
//echo "inserir OK";
}     



?>