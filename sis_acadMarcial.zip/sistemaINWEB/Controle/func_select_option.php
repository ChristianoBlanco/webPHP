<?php

function opt_nivel($nvl){
	
 if($nvl == 0){

 $nvl = "Visitante";
 return $nvl;
 }
 if($nvl == 1){

 $nvl = "Usuário";
 return $nvl;
 } 
 if($nvl == 2){

 $nvl = "Super usuário";
 return $nvl;
 }
 if($nvl == 3){

 $nvl = "Administrador";
 return $nvl;
 }

}

function opt_nivel_prof($nvl){
	
 if($nvl == 0){

 $nvl = "Ensino fundamental";
 return $nvl;
 }
 if($nvl == 1){

 $nvl = "Ensino médio";
 return $nvl;
 } 
 if($nvl == 2){

 $nvl = "Graduação";
 return $nvl;
 }
 if($nvl == 3){

 $nvl = "Pós graduação";
 return $nvl;
 }
 if($nvl == 4){

 $nvl = "Mestrado";
 return $nvl;
 }
 if($nvl == 5){

 $nvl = "Estágio";
 return $nvl;
 }

}
function opt_status_prof($nvl){
	
 if($nvl == "C"){

 $nvl = "Completo";
 return $nvl;
 }
 if($nvl == "I"){

 $nvl = "Incompleto";
 return $nvl;
 }
 if($nvl == "A"){

 $nvl = "Andamento";
 return $nvl;
 }

}
function opt_semana($nvl){
	
 if($nvl == "1"){

 $nvl = "Segunda";
 return $nvl;
 }
 if($nvl == "2"){

 $nvl = "Terça";
 return $nvl;
 }
 if($nvl == "3"){

 $nvl = "Quarta";
 return $nvl;
 }
 if($nvl == "4"){

 $nvl = "Quinta";
 return $nvl;
 }
 if($nvl == "5"){

 $nvl = "Sexta";
 return $nvl;
 }
 if($nvl == "6"){

 $nvl = "Sábado";
 return $nvl;
 }
 if($nvl == "7"){

 $nvl = "Domingo";
 return $nvl;
 }

}


?>

