<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php 
session_start();
include("func_convert_data.php");
include("../Modelo/conn_conect.php"); //Conexão com o banco local ou de Intranet.


class add 
{

var $id_usu, $dt_usu, $nome_usu, $login, $senha, $nivel_ac, $ins, $ins2, $upd, $del, $sel, $sql_ins, $sql_ins2, $res_ins, $sql_upd, $res_upd;

   
   
   function inserir_pagamento()
   {
	  include("../Modelo/sql_insert_pagamento.php");
	  $this->ins = mysql_query($this->sql_ins);
	  
	  //Passa matricula para a etapa de matricular atividades
	  $_SESSION["passa_matricula"] = $this->mat_alu;
	  
	  //Passa nome do aluno atraves do id para etapa de matricular atividades
	  $this->idDoAluno = $this->id_alu;
	  $this->sql_conv_id = mysql_query("SELECT id_aluno, nome_alu FROM tb_aluno WHERE id_aluno = $this->idDoAluno ");
	  $this->row_conv_id = mysql_fetch_array($this->sql_conv_id);
	  print $_SESSION["passa_nomeAluno"] = $this->row_conv_id["nome_alu"];
	  $_SESSION["passa_idAluno"]   = $this->row_conv_id["id_aluno"];
	  $_SESSION["mat_alu"]         = $this->mat_alu;
	  $_SESSION["valor_t"]         = $this->valor_t;
	  $_SESSION["status_pl"]       = $this->status_pl;
	  
	  //incluir novo pagamento em aberto(A) a partir da nova data de vencimento
	  //Calcula nova data de vencimento
	  include("func_data_venci.php");//Função de calc de data de vencimento
	  $this->dt_calc = databr($this->dt_venc)."<br>";
	  $this->dias = "30";
	  $this->res_dt_calc = CalcularVencimento($this->dt_calc,$this->dias);
	  $this->dt_venc2 = datasql($this->res_dt_calc);
	  $this->status_pg2 = "A";
	  $this->dt_pag2 = "";
	  /////////////////////////////////////////////////////////////////////
	  
	  $this->ins2 = mysql_query("INSERT INTO tb_pagamento (id_pg, id_alu, mat_alu, status_pg, dt_venc, dt_pag, multa, valor_t) 
      VALUES 
      (
	   '','$this->id_alu',
	   '$this->mat_alu',
	   '$this->status_pg2',
       '$this->dt_venc2',
       '$this->dt_pag2',
       '$this->multa',
       '$this->valor_t')");   
	  
	  $this->up01 = mysql_query("UPDATE tb_matricula SET 
								situacao='A' 
								WHERE mat_alu='$this->mat_alu'"); 
	 
	  //$_SESSION["msg"] = "<font color='#0066FF'>"."PRIMEIRO PAGAMENTO DE MATRICULA com sucesso!"."</font>"; //Mensagem exibição para a pagina 
      print "<meta HTTP-EQUIV='Refresh' CONTENT='0;URL=../Visao/index.php?active5=active&page=4&fun=21&t_sel=$this->status_pl&status_pg=$this->status_pg'>";
   }
   
   
   function alterar_pagamento()
   {
	
   }

   function deletar_pagamento()
   {
   
   }

}
$add = new add();
//Variável que recebe a id do usuário pelo _POST do form, que recebe através do primeiro $recebe_get que é igual a _GET da url 
$recebe_post = $_POST["t_mat_alu"];



    $add->id_alu    = $_POST["t_id_alu"];
	$add->mat_alu   = $_POST["t_mat_alu"];
	$add->status_pg = $_POST["t_status_pg"];
    $add->dt_venc   = datasql($_POST["t_dt_venc"]);
	$add->dt_pag    = datasql($_POST["t_dt_pag"]);
	$add->multa     = $_POST["t_multa"];
	$add->valor_t   = $_POST["t_valor_t"];
	$add->status_pl = $_POST["t_status_pl"];
	

$add->inserir_pagamento();
//echo "inserir OK";
   



?>