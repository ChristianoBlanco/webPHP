﻿<?php 
$data_venc  = '2017-05-13';
//$data_atual = date("Y-m-d");
$data_atual = '2017-05-10';

// Comparando as Datas
if(strtotime($data_atual) > strtotime($data_venc))
{
echo 'Em Débito';
}
elseif(strtotime($data_atual) == strtotime($data_venc))
{
echo 'Venceu';
}
else
{
echo 'Em dia';
}
echo "<br/>"."Cálculos com datas"."<br/>";

//Quantos dias faltam para pagar

if(strtotime($data_atual) <= strtotime($data_venc)){
 $diferenca_c = strtotime($data_atual) - strtotime($data_venc);
 $dias_c = floor($diferenca_c / (60*60*24));
 echo "Ainda restam ".abs($dias_c)." de créditos";
}else{
 


/* $diferenca_d = strtotime($data_atual) + strtotime($data_venc);
 $dias_d = abs($diferenca_d / (24*60*60));
 echo "Ainda restam ".floor($dias_d)." de créditos";*/
 

// converte as datas para o formato timestamp
$d1 = strtotime("$data_atual"); 
$d2 = strtotime("$data_venc");

// verifica a diferença em segundos entre as duas datas e divide pelo número de segundos que um dia possui
$dataFinal = ($d2 - $d1) /86400;

// caso a data 2 seja menor que a data 1
if($dataFinal < 0)
$dataFinal = $dataFinal * -1;

echo "Entre as duas datas informadas, existem $dataFinal dias.";

} 
?>
