Author : Ali Aboussebaba
Source from : http://www.bewebdeveloper.com
Subject : PHP MVC example

To explore the full tutorial about this source, go to:
http://www.bewebdeveloper.com/tutorial-about-autocomplete-using-php-mysql-and-jquery
