﻿<?php 

function converte_nome_ativ($id_convid){

$sql_convertAtiv = mysql_query("SELECT id_ativ, nome_ativ FROM tb_atividade WHERE id_ativ = '$id_convid'");
$row_convertAtiv = mysql_fetch_array($sql_convertAtiv);
return $row_convertAtiv["nome_ativ"];

}
function converte_id_ativ($id_convid){

$sql_convertAtiv = mysql_query("SELECT id_ativ, nome_ativ FROM tb_atividade WHERE nome_ativ = '$id_convid'");
$row_convertAtiv = mysql_fetch_array($sql_convertAtiv);
return $row_convertAtiv["id_ativ"];

}

?>
