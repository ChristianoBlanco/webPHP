
<?php 
session_start();
include("func_convert_data.php");
include("../Modelo/conn_conect.php"); //Conexão com o banco local ou de Intranet.


class add 
{

var $id_usu, $dt_usu, $nome_usu, $login, $senha, $nivel_ac, $ins, $upd, $del, $sel, $sql_ins, $res_ins, $sql_upd, $res_upd;

   
   
   function inserir_ativ()
   {
	  include("../Modelo/sql_insert_ativ.php");
	  $this->ins = mysql_query($this->sql_ins);
	  $_SESSION["msg"] = "<font color='#0066FF'>"."Atividade INSERIDA com sucesso!"."</font>"; //Mensagem exibição para a pagina 
      print "<meta HTTP-EQUIV='Refresh' CONTENT='0;URL=../Visao/index.php?active4=active&page=3&fun=13'>";
   }
   
   function selecionar_ativ()
   {
   
   }
   
   function alterar_ativ()
   {
	include("../Modelo/sql_update_ativ.php"); 
    $this->upd = mysql_query($this->sql_upd) or die('Erro:' . mysql_error());
	$_SESSION["msg"] = "<font color='#0066FF'>"."Atividade ALTERADA com Sucesso!"."</font>"; //Mensagem exibição para a pagina 
    print "<meta HTTP-EQUIV='Refresh' CONTENT='0;URL=../Visao/index.php?active4=active&page=3&fun=13&id_ativ=$recebe_get'>";
   }

   function deletar_ativ()
   {
   
   }

}
$add = new add();
//Variável que recebe a id do usuário pelo _POST do form, que recebe através do primeiro $recebe_get que é igual a _GET da url 
$recebe_post = $_POST["t_id_ativ"];


if($recebe_post <> " "){
 $add->id_ativ     = $_POST["t_id_ativ"];
 $add->nome_ativ   = $_POST["t_nome_ativ"];
 $add->valor       = $_POST["t_valor_ativ"];
 $add->status_pl   = $_POST["t_status_pl"];
 $add->id_func     = $_POST["t_id_func"];
 
 $add->alterar_ativ();
 //echo "senha OK";
}
if($recebe_post == ""){
 $add->id_ativ     = $_POST["t_id_ativ"];
 $add->nome_ativ   = $_POST["t_nome_ativ"];
 $add->valor       = $_POST["t_valor_ativ"];
 $add->status_pl   = $_POST["t_status_pl"];
 $add->id_func     = $_POST["t_id_func"];

 $add->inserir_ativ();
 //echo "inserir OK";
}     



?>