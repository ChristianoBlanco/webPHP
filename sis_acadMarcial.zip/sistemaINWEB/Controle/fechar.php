<?php
ob_start();
//INICIALIZA A SESSÃO
session_start();
//error_reporting(0);
//DESTRÓI AS SESSOES
//unset($_SESSION[usuario]);
//unset($_SESSION[validacao]);
unset($_SESSION["login"]);
unset($_SESSION["senha"]);
unset($_SESSION["id_usu"]);
session_destroy();

//REDIRECIONA PARA A TELA DE LOGIN
print "<meta HTTP-EQUIV='Refresh' CONTENT='0;URL=../Visao/login.php'>";
?> 