﻿<?php 
	include("func_convert_data.php");
    include("class_pag_con_pagamento.php");
    ?>          
    <?php
    //Chamo a classe
    $paginacao = new paginacao();
    $paginacao->qtn = 6;// determina a quantidade de elementos na barra de navegação
    $paginacao->ttpg = 6;// total de registros por página
    $paginacao->pg = @$_GET["pg"];

    include("../Modelo/sql_paginacao_pesq_e_ord_pagamento.php"); //Chama SQL de pesquisa e ordenação para paginação 
    ?>
    <?php $paginacao->config_paginacao();// Chama a função de paginação da class paginacao() ?>     