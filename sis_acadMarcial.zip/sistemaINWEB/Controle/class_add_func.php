
<?php 
session_start();
include("func_convert_data.php");
include("../Modelo/conn_conect.php"); //Conexão com o banco local ou de Intranet.


class add 
{

var $id_usu, $dt_usu, $nome_usu, $login, $senha, $nivel_ac, $ins, $upd, $del, $sel, $sql_ins, $res_ins, $sql_upd, $res_upd;

   
   
   function inserir_func()
   {
	  include("../Modelo/sql_insert_func.php");
	  $this->ins = mysql_query($this->sql_ins);
	  $_SESSION["msg"] = "<font color='#0066FF'>"."Funcionário INSERIDO com sucesso!"."</font>"; //Mensagem exibição para a pagina 
      print "<meta HTTP-EQUIV='Refresh' CONTENT='0;URL=../Visao/index.php?active3=active&page=2&fun=10'>";
   }
   
   function selecionar_func()
   {
   
   }
   
   function alterar_func()
   {
	include("../Modelo/sql_update_func.php"); 
    $this->upd = mysql_query($this->sql_upd) or die('Erro:' . mysql_error());
	$_SESSION["msg"] = "<font color='#0066FF'>"."Funcionário ALTERADO com Sucesso!"."</font>"; //Mensagem exibição para a pagina 
    print "<meta HTTP-EQUIV='Refresh' CONTENT='0;URL=../Visao/index.php?active3=active&page=2&fun=10&id_func=$recebe_get'>";
   }

   function deletar_func()
   {
   
   }

}
$add = new add();
//Variável que recebe a id do usuário pelo _POST do form, que recebe através do primeiro $recebe_get que é igual a _GET da url 
$recebe_post = $_POST["t_id_func"];


if($recebe_post <> " "){
 $add->id_func     = $_POST["t_id_func"];
 $add->nome_func   = $_POST["t_nome_func"];
 $add->dt_nas      = datasql($_POST["t_dt_nas"]);
 $add->sexo        = $_POST["t_sexo"];
 $add->prof        = $_POST["t_prof"];
 $add->nivel_prof  = $_POST["t_nivel_prof"];
 $add->status_prof = $_POST["t_status_prof"];
 $add->cpf         = $_POST["t_cpf"];
 $add->id          = $_POST["t_id"];
 $add->org_exp     = $_POST["t_org_exp"];
 $add->ende        = $_POST["t_end"];
 $add->bairro      = $_POST["t_bairro"];
 $add->cidade      = $_POST["t_cidade"];
 $add->cep         = $_POST["t_cep"];
 $add->tel         = $_POST["t_tel"];
 $add->cel         = $_POST["t_cel"];
 $add->email       = $_POST["t_email"];
 $add->obs         = $_POST["t_obs"];
 $add->dt_cri      = $_POST["t_dt_cri"];
 $add->alterar_func();
 //echo "senha OK";
}
if($recebe_post == ""){
//$add->id_aluno    = $_POST["t_id_aluno"];
 $add->id_func     = $_POST["t_id_func"];
 $add->nome_func   = $_POST["t_nome_func"];
 $add->dt_nas      = datasql($_POST["t_dt_nas"]);
 $add->sexo        = $_POST["t_sexo"];
 $add->prof        = $_POST["t_prof"];
 $add->nivel_prof  = $_POST["t_nivel_prof"];
 $add->status_prof = $_POST["t_status_prof"];
 $add->cpf         = $_POST["t_cpf"];
 $add->id          = $_POST["t_id"];
 $add->org_exp     = $_POST["t_org_exp"];
 $add->ende        = $_POST["t_end"];
 $add->bairro      = $_POST["t_bairro"];
 $add->cidade      = $_POST["t_cidade"];
 $add->cep         = $_POST["t_cep"];
 $add->tel         = $_POST["t_tel"];
 $add->cel         = $_POST["t_cel"];
 $add->email       = $_POST["t_email"];
 $add->obs         = $_POST["t_obs"];
 $add->dt_cri      = $_POST["t_dt_cri"];
$add->inserir_func();
//echo "inserir OK";
}     



?>