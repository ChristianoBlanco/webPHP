<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php 
session_start();
include("func_convert_data.php");
include("../Modelo/conn_conect.php"); //Conexão com o banco local ou de Intranet.


class add 
{

var $id_usu, $dt_usu, $nome_usu, $login, $senha, $nivel_ac, $ins, $upd, $del, $sel, $sql_ins, $res_ins, $sql_upd, $res_upd;

   
   
   function inserir_matricula_ativ()
   {
	  
	  
	  //print "TESTE<br>";
	  //Select para pegar o valor da atividade à cadastrar.
	  //$this->idAtividade = $this->id_ativ;
	  //$this->sql_conv_id = mysql_query("SELECT id_ativ, valor FROM tb_atividade WHERE id_ativ = $this->idAtividade");
	  //$this->row_conv_id = mysql_fetch_array($this->sql_conv_id);
	  
	  //$this->valor_ativ  = $this->valor_avu;  
	  $this->valor_p  =  $this->valor_avu - $this->desc;
	 
	  include("../Modelo/sql_insert_matricula_ativ.php");
	  $this->ins = mysql_query($this->sql_ins);
	  
	  //Variaveis de sessão que retornam valores de matricula e id do aluno para a pag anterior.
	  @$_SESSION["passa_matricula"] = $this->mat_alu;
	  @$_SESSION["passa_idAluno"]   = $this->id_alu;
	  
	  $_SESSION["msg"] = "<font color='#0066FF'>"."Atividades da Matrícula INSERIDA com sucesso!"."</font>"; //Mensagem exibição para a pagina 
      print "<meta HTTP-EQUIV='Refresh' CONTENT='0;URL=../Visao/index.php?active5=active&page=4&fun=17&status_pg=&t_sel=$this->status_pl'>";
   }
   
   function selecionar_ativ()
   {
   
   }
   
   function alterar_ativ()
   {
	include("../Modelo/sql_update_ativ.php"); 
    $this->upd = mysql_query($this->sql_upd) or die('Erro:' . mysql_error());
	$_SESSION["msg"] = "<font color='#0066FF'>"."Atividade ALTERADA com Sucesso!"."</font>"; //Mensagem exibição para a pagina 
    //print "<meta HTTP-EQUIV='Refresh' CONTENT='0;URL=../Visao/index.php?active4=active&page=3&fun=13&id_ativ=$recebe_get'>";
   }

   function deletar_ativ()
   {
   
   }

}
$add = new add();
//Variável que recebe a id do usuário pelo _POST do form, que recebe através do primeiro $recebe_get que é igual a _GET da url 
$recebe_post = $_POST["t_mat_alu"];


 
//$add->id_mat     = $_POST["t_id_mat"];
$add->id_alu     = $_POST["t_nome_alu"];
$add->mat_alu    = $_POST["t_mat_alu"];	
$add->id_ativ    = $_POST["t_id_ativ"];
$add->valor_avu  = $_POST["t_valor_p"];
$add->desc       = $_POST["t_id_desc"];
$add->status_pl  =  $_POST["t_status_pl"];	
$add->status_pg  =  $_POST["t_status_pg"];	


$add->inserir_matricula_ativ();
//echo "inserir OK";
  



?>