<?php 
//session_start();
include("../Modelo/conn_conect.php"); 
?>

<?php 

$fun = 0; //FUNCAO STATUS
if(isset($_GET["fun"])){$fun = $_GET["fun"];}

switch($fun){

  case 0: ?>
  <div class="templatemo-flex-row flex-content-row">
            
   <div class="templatemo-content-widget white-bg col-2">
              <!-- i class="fa fa-times"></i -->
              <!-- div class="square"></div -->
      <h5 align="center" style="font-weight:bold;">Resumo de situação de matrículas</h5> 
      <table width='500' border='0' cellspacing='0' cellpadding='0' class='table table-striped table-bordered'>
      <tr>
      <td>Matrículas em Débito</td>
      </tr>
      <tr>
      <td>Matrículas para Vencer</td>
      </tr>
      <tr>
      <td>Matrícuas em Dia</td>
      </tr>
      </table>
      
      <h5 align="center" style="font-weight:bold;">Resumo de situação de alunos</h5> 
      <table width='500' border='0' cellspacing='0' cellpadding='0' class='table table-striped table-bordered'>
      <tr>
      <td>Total de alunos ativos</td>
      </tr>
      <tr>
      <td>Total de alunos inativos/trancados</td>
      </tr>
      <tr>
      <td>Total de alunos isentos</td>
      </tr>
      </table>
      
      <h5 align="center" style="font-weight:bold;">Resumo de situação de pagamentos</h5> 
      <table width='500' border='0' cellspacing='0' cellpadding='0' class='table table-striped table-bordered'>
      <tr>
      <td>Valor total de pagamentos</td>
      </tr>
      <tr>
      <td>Valor total de pagamentos em crédito</td>
      </tr>
      <tr>
      <td>Valor total de pagamentos em débito</td>
      </tr>
      </table>             
                       
   </div>
  </div>     
  <?php
   //fim case 0
   break;	
   ?>
   
   
   <?php
   case 1: //FUNÃ‡ÃƒO CALCULADORA
   ?>
   <div class="templatemo-flex-row flex-content-row">
            
   <div class="templatemo-content-widget white-bg col-2">
              <!-- i class="fa fa-times"></i -->
              <!-- div class="square"></div -->
    <?php echo "teste content pag calculadora"; ?>          
                       
   </div>
  </div>  
   <?php
   //fim case 1
   break; 
   ?>
   
   
   <?php
   case 2: //FUNÃ‡ÃƒO CALENDÃ�RIO
   ?>
   <div class="templatemo-flex-row flex-content-row">
            
   <div class="templatemo-content-widget white-bg col-2">
              <!-- i class="fa fa-times"></i -->
              <!-- div class="square"></div -->
    <?php echo "teste content pag calendÃ¡rio"; ?>          
                       
   </div>
  </div>  
   <?php
   //fim case 2
   break; 
   ?>
  
   
   <?php
   case 3: //FUNÃ‡ÃƒO CRIA/ALTERA USUARIO
   ?>
   <div class="templatemo-flex-row flex-content-row">
            
   <div class="templatemo-content-widget white-bg col-2">
              <!-- i class="fa fa-times"></i -->
              <!-- div class="square"></div -->
    
            <?php
		   //Limpa os campos se carregados pÃ³s aleraÃ§Ã£o
		   if(empty($_GET["id_usu"]))
		   {
			$_SESSION["id_usu"]      = ""; 
			$_SESSION["nome_usu"]    = ""; 
			$_SESSION["t_login"]     = ""; 
			$_SESSION["t_senha"]     = "";
			$_SESSION["nivel_ac"]    = "";
			$_SESSION["titulo_tb"]   = "INCLUSÃƒO DE USUÃ�RIO";  
		   }
		   ?>
           <?php 
		   include("func_select_option.php");
		   include("../Controle/class_se_existe.php");
		   $se_existe = new se_existe();
		   include("../Modelo/sql_existe_usuario.php");
           $se_existe->se_existe_usu();
		   
           if(isset($se_existe->res_conf["id_usu"]))
		   {
			$_SESSION["id_usu"]      = $se_existe->res_conf["id_usu"]; 
			$_SESSION["nome_usu"]    = $se_existe->res_conf["nome_usu"]; 
			$_SESSION["t_login"]     = $se_existe->res_conf["login"]; 
			$_SESSION["t_senha"]     = $se_existe->res_conf["senha"];
			$_SESSION["nivel_ac"]    = $se_existe->res_conf["nivel_ac"];
			$_SESSION["titulo_tb"]   = "ALTERAÃ‡ÃƒO DE USUÃ�RIO";  
		   }
		   ?> 
             
   <form action="../Controle/class_add_adm.php" enctype="multipart/form-data" method="post">
     <table width="850" border="0" >
     <tr>
     <td style="font-weight:bold;"><?php echo $_SESSION["titulo_tb"]; ?></td>
     <td align="right"><a href="../Visao/index.php" target="_parent"><img src="../Visao/images/buttons/Sair_over.png" width="26" height="26" title="Voltar"></a></td>
     </tr>
     </table>
     <br/>
     <table width="500" border="0" class="table table-striped table-bordered">
       <input type="hidden" name="t_dt_usu" value="<?php echo date("d/m/Y"); ?>" size="10" maxlength="11" />
       
       <input type="hidden" name="t_id_usu" value="<?php echo $_SESSION["id_usu"]; ?> " size="10" maxlength="11" />  
       <tr>
       <td align="right">Nome:</td>
       <td width="367"><input type="text" name="t_nome_usu" value="<?php echo $_SESSION["nome_usu"]; ?>" size="60" maxlength="60" required="required" />       </td>
       </tr>
       <tr>
       <td align="right">Login:</td>
       <td>&nbsp;<input type="text" name="t_log_usu" value="<?php echo $_SESSION["t_login"]; ?>" size="30" maxlength="30" required="required" /></td>
       </tr>
       <tr>
       <td align="right">Nova senha:</td>
       <td>&nbsp;<input type="password" name="t_senha_usu" value="<?php //echo $_SESSION["t_senha"]; ?>" size="30" maxlength="30" required="required" />       </td>
       </tr>
       <tr>
       <td align="right">Confirma senha:</td>
       <td>&nbsp;<input type="password" name="t_csenha_usu" value="<?php //echo $_SESSION["t_senha"]; ?>" size="30" maxlength="30" required="required" />       </td>
       </tr>
       <tr>
       <td align="right">Nivel de acesso: </td>
       <td>&nbsp;
       <select name="t_nivel_usu" required>
       <option value="<?php echo $_SESSION["nivel_ac"]; ?>" selected="selected" style="font-weight:bold; text-decoration:underline;"><?php echo opt_nivel($_SESSION["nivel_ac"]); ?></option>
       <option value="3">Administrador</option>
       <option value="2">Super usuÃ¡rio</option>
       <option value="1">UsuÃ¡rio</option>
       <option value="0">Visitante</option>
       </select>
       </td>
       </tr>
       </table>
       <table width="850" border="0" >
       <tr>
       <td width="217">&nbsp;</td>
       </tr>
       <tr>
       <td>
       <button type="submit" class="templatemo-blue-button width-10" name="bt_adm_grava" onclick="return confirm('Confirma os dados?')" />Gravar</button>
       </td>
       <td width="273" style="color:#F00;">
	   <?php echo @$_SESSION["msg"]; @$_SESSION["msg"] = "";?>
       <a href="../Visao/index.php?active1=active&page=0&fun=4" target="_parent" ><div align="right" style="float:right; color:#000">&raquo;&nbsp;Consultar usuÃ¡rios</div></a>
       </td>
       </tr>
       
     </table>
   </form>                    
   </div>
   </div>  
   <?php
   //fim case 3
   break; 
   ?>
   
   
   <?php
   case 4: //FUNÃ‡ÃƒO CONSULTA USURAIO
   ?>
   <div class="templatemo-flex-row flex-content-row">
            
   <div class="templatemo-content-widget white-bg col-2">
   <!-- i class="fa fa-times"></i -->
   <!-- div class="square"></div -->
    <?php 
	include("func_convert_data.php");
	include("func_select_option.php");
    include("class_pag_con_adm.php");
    ?>          
    <?php
    //Chamo a classe
    $paginacao = new paginacao();
    $paginacao->qtn = 6;// determina a quantidade de elementos na barra de navegaÃ§Ã£o
    $paginacao->ttpg = 6;// total de registros por pÃ¡gina
    $paginacao->pg = @$_GET["pg"];

    include("../Modelo/sql_paginacao_pesq_e_ord_adm.php"); //Chama SQL de pesquisa e ordenaÃ§Ã£o para paginaÃ§Ã£o 
    ?>
    <?php $paginacao->config_paginacao();// Chama a funÃ§Ã£o de paginaÃ§Ã£o da class paginacao() ?>
                      
    </div>
    </div>  
   <?php
   //fim case 4
   break; 
   ?>
   
   
   
   <?php
   case 5: //FUNÃ‡ÃƒO GOOGLE MAPS
   ?>
   <div class="templatemo-flex-row flex-content-row">
            
   <div class="templatemo-content-widget white-bg col-2">
              <!-- i class="fa fa-times"></i -->
              <!-- div class="square"></div -->
    <?php echo "teste content pag Google Maps"; ?>          
                       
   </div>
  </div>  
   <?php
   //fim case 5
   break; 
   ?>


    <?php
   case 6: //FUNÃ‡ÃƒO MINHA CONTA
   ?>
   <div class="templatemo-flex-row flex-content-row">
            
   <div class="templatemo-content-widget white-bg col-2">
           <?php 
		   include("func_select_option.php");
		   include("../Controle/class_se_existe.php");
		   $se_existe = new se_existe();
		   include("../Modelo/sql_existe_usuario_conta.php");
           $se_existe->se_existe_usu();
		   
           if(isset($se_existe->res_conf["id_usu"]))
		   {
			$_SESSION["id_usu"]      = $se_existe->res_conf["id_usu"]; 
			$_SESSION["nome_usu"]    = $se_existe->res_conf["nome_usu"]; 
			$_SESSION["t_login"]     = $se_existe->res_conf["login"]; 
			$_SESSION["t_senha"]     = $se_existe->res_conf["senha"];
			$_SESSION["nivel_ac"]    = $se_existe->res_conf["nivel_ac"];
			$_SESSION["titulo_tb"]   = "MINHA CONTA";  
		   }
		   ?>
           <form action="../Controle/class_add_adm_conta.php" enctype="multipart/form-data" method="post">
           <table width="850" border="0" >
           <tr>
           <td style="font-weight:bold;"><?php echo $_SESSION["titulo_tb"]; ?></td>
           <td align="right"><a href="../Visao/index.php" target="_parent"><img src="../Visao/images/buttons/Sair_over.png" width="26" height="26" title="Voltar"></a></td>
           </tr>
           </table>
           <br/>
           <table width="500" border="0" class="table table-striped table-bordered">
          <input type="hidden" name="t_dt_usu" value="<?php echo date("d/m/Y"); ?>" size="10" maxlength="11" />
       
          <input type="hidden" name="t_id_usu" value="<?php echo $_SESSION["id_usu"]; ?> " size="10" maxlength="11" />
          <input type="hidden" name="t_log_usu" value="<?php echo $_SESSION["t_login"]; ?>" size="30" maxlength="30"  />
          <input type="hidden" name="t_nivel_usu" value="<?php echo $_SESSION["nivel_ac"]; ?>" size="30" maxlength="30" />  
          <tr>
       <td align="right">Nome:</td>
       <td width="367"><input type="text" name="t_nome_usu" value="<?php echo $_SESSION["nome_usu"]; ?>" size="60" maxlength="60" required="required" /></td>
       </tr>
       <!--tr>
       <td align="right">Login:</td>
       <td>&nbsp;</td>
       </tr>
       <tr -->
       <td align="right">Nova senha:</td>
       <td>&nbsp;<input type="password" name="t_senha_usu" value="<?php //echo $_SESSION["t_senha"]; ?>" size="30" maxlength="30" required="required" /></td>
       </tr>
       <tr>
       <td align="right">Confirma senha:</td>
       <td>&nbsp;<input type="password" name="t_csenha_usu" value="<?php //echo $_SESSION["t_senha"]; ?>" size="30" maxlength="30" required="required" /></td>
       </tr>
       <!-- tr>
       <td align="right">Nivel de acesso: </td>
       <td>&nbsp;
       <select name="t_nivel_usu" required>
       <option value="<?php //echo $_SESSION["nivel_ac"]; ?>" selected="selected" style="font-weight:bold; text-decoration:underline;"><?php //echo opt_nivel($_SESSION["nivel_ac"]); ?></option>
       <option value="3">Administrador</option>
       <option value="2">Super usuÃ¡rio</option>
       <option value="1">UsuÃ¡rio</option>
       <option value="0">Visitante</option>
       </select>
       </td>
       </tr -->
       </table>
       <table width="850" border="0" >
       <tr>
       <td width="217">&nbsp;</td>
       </tr>
       <tr>
       <td>
       <button type="submit" class="templatemo-blue-button width-10" name="bt_adm_grava" onclick="return confirm('Confirma os dados?')" />Gravar</button>
       </td>
       <td width="273" style="color:#F00;">
	   <?php echo @$_SESSION["msg"]; @$_SESSION["msg"] = "";?>
       <a href="../Visao/index.php?active1=active&page=0&fun=4" target="_parent" ><div align="right" style="float:right; color:#000">&raquo;&nbsp;Consultar usuÃ¡rios</div></a>
       </td>
       </tr>
       
     </table>
     </form>     
                       
   </div>
  </div>  
   <?php
   //fim case 6
   break; 
   ?>   
   
   
   
   <?php
   case 7: //FUNÃ‡ÃƒO CADASTRA/ALTERA ALUNOS
   ?>
   <div class="templatemo-flex-row flex-content-row">
            
   <div class="templatemo-content-widget white-bg col-2">
             <?php
		   //Limpa os campos se carregados pÃ³s aleraÃ§Ã£o
		   include("func_convert_data.php");
		   if(empty($_GET["id_aluno"]))
		   {
			$_SESSION["id_aluno"]      = ""; 
			$_SESSION["nome_alu"]      = ""; 
			$_SESSION["dt_nas"]        = ""; 
			$_SESSION["sexo"]          = "";
			$_SESSION["cpf"]           = "";
			$_SESSION["id"]            = "";
			$_SESSION["org_exp"]       = "";
			$_SESSION["resp_nome_alu"] = "";
			$_SESSION["resp_cpf"]      = "";
			$_SESSION["resp_id"]       = "";
			$_SESSION["resp_org_exp"]  = "";
			$_SESSION["end"]           = "";
			$_SESSION["bairro"]        = "";
			$_SESSION["cidade"]        = "";
			$_SESSION["cep"]           = "";
			$_SESSION["tel"]           = "";
			$_SESSION["cel"]           = "";
			$_SESSION["email"]         = "";
			$_SESSION["obs"]           = "";
			$_SESSION["dt_cri"]        = "";
			$_SESSION["mat_alu"]       = "";
			$_SESSION["titulo_tb"]     = "INCLUSÃƒO DE ALUNO";  
		   }
		   ?>
           <?php 
		   include("../Controle/class_se_existe.php");
		   $se_existe = new se_existe();
		   include("../Modelo/sql_existe_aluno.php");
           $se_existe->se_existe_alu();
		   
           if(isset($se_existe->res_conf["id_aluno"]))
		   {
			 
			$_SESSION["id_aluno"]      = $se_existe->res_conf["id_aluno"]; 
			$_SESSION["nome_alu"]      = $se_existe->res_conf["nome_alu"];
			$_SESSION["dt_nas"]        = $se_existe->res_conf["dt_nas"]; 
			$_SESSION["sexo"]          = $se_existe->res_conf["sexo"];
			$_SESSION["cpf"]           = $se_existe->res_conf["cpf"];
			$_SESSION["id"]            = $se_existe->res_conf["id"];
			$_SESSION["org_exp"]       = $se_existe->res_conf["org_exp"];
			$_SESSION["resp_nome_alu"] = $se_existe->res_conf["resp_nome_alu"];
			$_SESSION["resp_cpf"]      = $se_existe->res_conf["resp_cpf"];
			$_SESSION["resp_id"]       = $se_existe->res_conf["resp_id"];
			$_SESSION["resp_org_exp"]  = $se_existe->res_conf["resp_org_exp"];
			$_SESSION["end"]           = $se_existe->res_conf["end"];
			$_SESSION["bairro"]        = $se_existe->res_conf["bairro"];
			$_SESSION["cidade"]        = $se_existe->res_conf["cidade"];
			$_SESSION["cep"]           = $se_existe->res_conf["cep"];
			$_SESSION["tel"]           = $se_existe->res_conf["tel"];
			$_SESSION["cel"]           = $se_existe->res_conf["cel"];
			$_SESSION["email"]         = $se_existe->res_conf["email"];
			$_SESSION["obs"]           = $se_existe->res_conf["obs"];
			$_SESSION["dt_cri"]        = $se_existe->res_conf["dt_cri"];
			$_SESSION["mat_alu"]       = $se_existe->res_conf["mat_alu"];
			$_SESSION["titulo_tb"]     = "ALTERAÃ‡ÃƒO DE ALUNO";  
		   }
		   ?>
        <form name="form1" action="../Controle/class_add_aluno.php" enctype="multipart/form-data" method="post">
        <input type="hidden" name="t_dt_cri" value="<?php echo $_SESSION["dt_cri"]; ?>" size="12" maxlength="10" />
        <input type="hidden" name="t_id_aluno" value="<?php echo $_SESSION["id_aluno"]; ?>" size="12" maxlength="10" />
        <table width="850" border="0" >
         <tr>
         <td style="font-weight:bold;"><?php echo $_SESSION["titulo_tb"]; ?></td>
         <td align="right">
         <?php echo @$_SESSION["msg"]; @$_SESSION["msg"] = "";?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         <a href="../Visao/index.php?active2=active&page=1&fun=8" target="_parent">
         <img src="../Visao/images/buttons/Sair_over.png" width="26" height="26" title= "Voltar"></a></td>
         </tr>
        </table>
        <br/>
        <table width="500" class="table table-striped table-bordered">
         <tr>
         <td>Nome:<br /><input type="texto" name="t_nome_alu" value="<?php echo $_SESSION["nome_alu"]; ?>" size="40" maxlength="60" required="required" /></td>
         <td>Data nas.:<br /><input type="texto" name="t_dt_nas" value="<?php echo databr($_SESSION["dt_nas"]); ?>" size="12" maxlength="10" required="required" onkeypress="return txtBoxFormat(document.form1, 't_dt_nas', '99/99/9999', event);"   /></td>
         </tr>
         <tr>
         <td>Sexo:<br />
         <select name="t_sexo" required>
         <option value="<?php echo $_SESSION["sexo"]; ?>" 
         selected="selected" style="font-weight:bold; text-decoration:underline;"><?php echo $_SESSION["sexo"]; ?></option>
         <option value="F">F</option>
         <option value="M">M</option>
         </select>
         </td>
         <td>CPF:<br /><input type="texto" name="t_cpf" onkeypress='return SomenteNumero(event)' value="<?php echo $_SESSION["cpf"]; ?>" size="15" maxlength="11" /></td>
         </tr>
         <tr>
         <td>ID:<br /><input type="texto" name="t_id" value="<?php echo $_SESSION["id"]; ?>" size="15" maxlength="20" /></td>
         <td>Org exp.:<br /><input type="texto" name="t_org_exp" value="<?php echo $_SESSION["org_exp"]; ?>" size="15" maxlength="10" /></td>
         </tr>
         <tr>
         <td>Nome resp.:<br /><input type="texto" name="t_resp_nome_alu" value="<?php echo $_SESSION["resp_nome_alu"]; ?>" size="40" maxlength="60" /></td>
         <td>CPF resp.:<br /><input type="texto" name="t_resp_cpf" onkeypress='return SomenteNumero(event)' value="<?php echo $_SESSION["resp_cpf"]; ?>" size="15" maxlength="11" /></td>
         </tr>
         <tr>
         <td>ID resp.:<br /><input type="texto" name="t_resp_id" value="<?php echo $_SESSION["resp_id"]; ?>" size="15" maxlength="20" /></td>
         <td>Org exp.:<br /><input type="texto" name="t_resp_org_exp" value="<?php echo $_SESSION["resp_org_exp"]; ?>" size="15" maxlength="10" /></td>
         </tr>
         <tr>
         <td>EndereÃ§o:<br /><input type="texto" name="t_end" value="<?php echo $_SESSION["end"]; ?>" size="40" maxlength="60" required="required"/></td>
         <td>Bairro:<br /><input type="texto" name="t_bairro" value="<?php echo $_SESSION["bairro"]; ?>" size="40" maxlength="40" required="required"/></td>
         </tr>
         <tr>
         <td>Cidade:<br /><input type="texto" name="t_cidade" value="<?php echo $_SESSION["cidade"]; ?>" size="40" maxlength="40" required="required"/></td>
         <td>CEP:<br /><input type="texto" name="t_cep" onkeypress="return txtBoxFormat(document.form1, 't_cep', '99999-999', event);"  value="<?php echo $_SESSION["cep"]; ?>" size="12" maxlength="9" /></td>
         </tr>
         <tr>
         <td>E-mail:<br /><input type="texto" name="t_email" value="<?php echo $_SESSION["email"]; ?>" size="40" maxlength="60" /></td>
         <td>Tel.:<br /><input type="texto" name="t_tel" onkeypress="return txtBoxFormat(document.form1, 't_tel', '(99)9999-9999', event);"value="<?php echo $_SESSION["tel"]; ?>" size="15" maxlength="13" required="required"/></td>
         </tr>
         <tr>
         <td>Cel.:<br /><input type="texto" name="t_cel" onkeypress="return txtBoxFormat(document.form1, 't_cel', '(21)99999-9999', event);" value="<?php echo $_SESSION["cel"]; ?>" size="15" maxlength="14" /></td>
         <td>&nbsp;</td>
         </tr>
         <tr>
         <td colspan="2">Obs:<br /><textarea name="t_obs" rows="5" cols="75"  multiple="multiple" value="" /><?php echo $_SESSION["obs"]; ?></textarea></td>
         </tr>
        </table>
        <br />
        <table width="850" border="0" >
        <tr>
        <td>
        <button type="submit" class="templatemo-blue-button width-10" name="bt_alu_grava" onclick="return confirm('Confirma os dados?')"/>Gravar</button>
        </td>
         <td width="273" style="color:#F00;">&nbsp;
	   
       </td>
         </tr>
        </table>
        </form>                   
   </div>
  </div>  
  
   <?php
   //fim case 7
   break; 
   ?>
   
   
   <?php
   case 8: //FUNÃ‡ÃƒO CONSULTA ALUNOS
   ?>
   <div class="templatemo-flex-row flex-content-row">
            
   <div class="templatemo-content-widget white-bg col-2">
              <!-- i class="fa fa-times"></i -->
              <!-- div class="square"></div -->
    <?php 
	include("func_convert_data.php");
    include("class_pag_con_alunos.php");
    ?>          
    <?php
    //Chamo a classe
    $paginacao = new paginacao();
    $paginacao->qtn = 6;// determina a quantidade de elementos na barra de navegaÃ§Ã£o
    $paginacao->ttpg = 6;// total de registros por pÃ¡gina
    $paginacao->pg = @$_GET["pg"];

    include("../Modelo/sql_paginacao_pesq_e_ord_alunos.php"); //Chama SQL de pesquisa e ordenaÃ§Ã£o para paginaÃ§Ã£o 
    ?>
    <?php $paginacao->config_paginacao();// Chama a funÃ§Ã£o de paginaÃ§Ã£o da class paginacao() ?>          
                       
   </div>
  </div>  
   <?php
   //fim case 8
   break; 
   ?>
  
   
   <?php
   case 9: //FUNÃ‡ÃƒO RELATORIO ALUNOS
   ?>
   <div class="templatemo-flex-row flex-content-row">
            
   <div class="templatemo-content-widget white-bg col-2">
              <!-- i class="fa fa-times"></i -->
              <!-- div class="square"></div -->
    <?php echo "teste content pag RelatÃ³rio alunos"; ?>          
                       
   </div>
  </div>  
   <?php
   //fim case 9
   break; 
   ?>
   
   
   <?php
   case 10: //FUNÃ‡ÃƒO CADASTRA/ALTERA FUNCIONARIOS
   ?>
   <div class="templatemo-flex-row flex-content-row">
            
   <div class="templatemo-content-widget white-bg col-2">
              <?php
		   //Limpa os campos se carregados pÃ³s aleraÃ§Ã£o
		   include("func_convert_data.php");
		   if(empty($_GET["id_func"]))
		   {
			$_SESSION["id_func"]    = ""; 
			$_SESSION["nome_func"]  = ""; 
			$_SESSION["dt_nas"]     = ""; 
			$_SESSION["sexo"]       = "";
			$_SESSION["prof"]       = "";
			$_SESSION["nivel_prof"] = "";
			$_SESSION["cpf"]        = "";
			$_SESSION["id"]         = "";
			$_SESSION["org_exp"]    = "";
			$_SESSION["end"]        = "";
			$_SESSION["bairro"]     = "";
			$_SESSION["cidade"]     = "";
			$_SESSION["cep"]        = "";
			$_SESSION["tel"]        = "";
			$_SESSION["cel"]        = "";
			$_SESSION["email"]      = "";
			$_SESSION["obs"]        = "";
			$_SESSION["dt_cri"]     = "";
			$_SESSION["titulo_tb"]     = "INCLUSÃƒO DE FUNCIONÃ�RIO";  
		   }
		   ?>
           <?php 
		   include("func_select_option.php");
		   include("../Controle/class_se_existe.php");
		   $se_existe = new se_existe();
		   include("../Modelo/sql_existe_funcionario.php");
           $se_existe->se_existe_func();
		   
           if(isset($se_existe->res_conf["id_func"]))
		   {
			 
			$_SESSION["id_func"]     = $se_existe->res_conf["id_func"]; 
			$_SESSION["nome_func"]   = $se_existe->res_conf["nome_func"];
			$_SESSION["dt_nas"]      = $se_existe->res_conf["dt_nas"]; 
			$_SESSION["sexo"]        = $se_existe->res_conf["sexo"];
			$_SESSION["prof"]        = $se_existe->res_conf["prof"];
			$_SESSION["nivel_prof"]  = $se_existe->res_conf["nivel_prof"];
			$_SESSION["status_prof"] = $se_existe->res_conf["status_prof"];
			$_SESSION["cpf"]         = $se_existe->res_conf["cpf"];
			$_SESSION["id"]          = $se_existe->res_conf["id"];
			$_SESSION["org_exp"]     = $se_existe->res_conf["org_exp"];
			$_SESSION["end"]         = $se_existe->res_conf["end"];
			$_SESSION["bairro"]      = $se_existe->res_conf["bairro"];
			$_SESSION["cidade"]      = $se_existe->res_conf["cidade"];
			$_SESSION["cep"]         = $se_existe->res_conf["cep"];
			$_SESSION["tel"]         = $se_existe->res_conf["tel"];
			$_SESSION["cel"]         = $se_existe->res_conf["cel"];
			$_SESSION["email"]       = $se_existe->res_conf["email"];
			$_SESSION["obs"]         = $se_existe->res_conf["obs"];
			$_SESSION["dt_cri"]      = $se_existe->res_conf["dt_cri"];
			$_SESSION["titulo_tb"]   = "ALTERAÃ‡ÃƒO DE FUNCIONÃ�RIO";  
		   }
		   ?>
        <form name="form1" action="../Controle/class_add_func.php" enctype="multipart/form-data" method="post">
        <input type="hidden" name="t_dt_cri" value="<?php echo $_SESSION["dt_cri"]; ?>" size="12" maxlength="10" />
        <input type="hidden" name="t_id_func" value="<?php echo $_SESSION["id_func"]; ?>" size="12" maxlength="10" />
        <table width="850" border="0" >
         <tr>
         <td style="font-weight:bold;"><?php echo $_SESSION["titulo_tb"]; ?></td>
         <td align="right">
         <?php echo @$_SESSION["msg"]; @$_SESSION["msg"] = "";?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         <a href="../Visao/index.php?active3=active&page=2&fun=11" target="_parent">
         <img src="../Visao/images/buttons/Sair_over.png" width="26" height="26" title= "Voltar"></a></td>
         </tr>
        </table>
        <br/>
        <table width="500" class="table table-striped table-bordered">
         <tr>
         <td>Nome:<br /><input type="texto" name="t_nome_func" value="<?php echo $_SESSION["nome_func"]; ?>" size="40" maxlength="60" 
         required="required" />
         </td>
         <td>Data nas.:<br /><input type="texto" name="t_dt_nas" value="<?php echo databr($_SESSION["dt_nas"]); ?>" size="12" maxlength="10" 
         required="required" onkeypress="return txtBoxFormat(document.form1, 't_dt_nas', '99/99/9999', event);"   />
         </td>
         </tr>
         <tr>
         <td>Sexo:<br />
         <select name="t_sexo" required>
         <option value="<?php echo $_SESSION["sexo"]; ?>" 
         selected="selected" style="font-weight:bold; text-decoration:underline;"><?php echo $_SESSION["sexo"]; ?></option>
         <option value="F">F</option>
         <option value="M">M</option>
         </select>
         </td>
         <td>ProfissÃ£o:<br /><input type="texto" name="t_prof" value="<?php echo $_SESSION["prof"]; ?>" 
         size="40" maxlength="40" />
         </td>
         </tr>
         <tr>
         <td>Nivel Prof.:<br />
         <select name="t_nivel_prof" required="required" >
         <option value="<?php echo $_SESSION["nivel_prof"]; ?>" selected="selected" style="font-weight:bold; text-decoration:underline;"><?php echo opt_nivel_prof($_SESSION["nivel_prof"]); ?></option>
         <option value="0">Ensino fundamental</option>
         <option value="1">Ensino mÃ©dio</option>
         <option value="2">GraduaÃ§Ã£o</option>
         <option value="3">PÃ³s graduaÃ§Ã£o</option>
         <option value="4">Mestrado</option>
         <option value="5">EstÃ¡gio</option>
         </select>
         Status curso:
         <select name="t_status_prof" required="required" >
         <option value="<?php echo $_SESSION["status_prof"]; ?>" selected="selected" style="font-weight:bold; text-decoration:underline;"><?php echo opt_status_prof($_SESSION["status_prof"]); ?></option>
         <option value="C">Completo</option>
         <option value="I">Incompleto</option>
         <option value="A">Andamento</option>
         </select>
         <td>CPF:<br /><input type="texto" name="t_cpf" onkeypress='return SomenteNumero(event)' value="<?php echo $_SESSION["cpf"]; ?>" size="15" maxlength="11" required="required" /></td>
         </tr>
         <tr>
         <td>id:<br /><input type="texto" name="t_id" value="<?php echo $_SESSION["id"]; ?>" size="15" maxlength="20" /></td>
         <td>Org_exp:<br /><input type="texto" name="t_org_exp" value="<?php echo $_SESSION["org_exp"]; ?>" 
         size="15" maxlength="20" />
         </td>
         </tr>
         <tr>
         <td>EndereÃ§o:<br /><input type="texto" name="t_end" value="<?php echo $_SESSION["end"]; ?>" size="40" maxlength="60" required="required" /></td>
         <td>Bairro:<br />
         <input type="texto" name="t_bairro" value="<?php echo $_SESSION["bairro"]; ?>" size="40" maxlength="40"  required="required"/>
         </td>
         </tr>
         <tr>
         <td>Cidade:<br />
         <input type="texto" name="t_cidade" value="<?php echo $_SESSION["cidade"]; ?>" size="40" maxlength="40" required="required"/>
         </td>
         <td>Cep:<br /><input type="texto" name="t_cep" onkeypress="return txtBoxFormat(document.form1, 't_cep', '99999-999', event);"  
         value="<?php echo $_SESSION["cep"]; ?>" size="12" maxlength="9" required="required"/>
         </td>
         </tr>
         <tr>
         <td>Tel.:<br /><input type="texto" name="t_tel" onkeypress="return txtBoxFormat(document.form1, 't_tel', '(99)9999-9999', event);" 
          value="<?php echo $_SESSION["tel"]; ?>" size="15" maxlength="13" required="required"/>
          </td>
         <td>Cel.:<br /><input type="texto" name="t_cel" onkeypress="return txtBoxFormat(document.form1, 't_cel', '(99)99999-9999', event);"  
         value="<?php echo $_SESSION["cel"]; ?>" size="15" maxlength="14" />
         </td>
         </tr>
         <tr>
         <td>E-mail:<br /><input type="texto" name="t_email" value="<?php echo $_SESSION["email"]; ?>" size="40" maxlength="60" /></td>
         <td>&nbsp;</td>
         </tr>
         <tr>
         <td colspan="2">Obs:<br />
         <textarea name="t_obs" rows="5" cols="75"  multiple="multiple" value="" /><?php echo $_SESSION["obs"]; ?></textarea>
         </td>
         </tr>
        </table>
        <br />
        <table width="850" border="0" >
         <tr>
         <td>
         <button type="submit" class="templatemo-blue-button width-10" name="bt_func_grava" onclick="return confirm('Confirma os dados?')"/>
         Gravar</button>
         </td>
         <td width="273" style="color:#F00;">&nbsp;
	     
          </td>
          </tr>
        </table>
        </form>      
                       
   </div>
  </div>  
   <?php
   //fim case 10
   break; 
   ?>
   
   
   <?php
   case 11: //FUNÃ‡ÃƒO CONSULTA FUNCIONARIOS
   ?>
   <div class="templatemo-flex-row flex-content-row">
            
   <div class="templatemo-content-widget white-bg col-2">
              <!-- i class="fa fa-times"></i -->
              <!-- div class="square"></div -->
    <?php 
	include("func_convert_data.php");
    include("class_pag_con_func.php");
    ?>          
    <?php
    //Chamo a classe
    $paginacao = new paginacao();
    $paginacao->qtn = 6;// determina a quantidade de elementos na barra de navegaÃ§Ã£o
    $paginacao->ttpg = 6;// total de registros por pÃ¡gina
    $paginacao->pg = @$_GET["pg"];

    include("../Modelo/sql_paginacao_pesq_e_ord_func.php"); //Chama SQL de pesquisa e ordenaÃ§Ã£o para paginaÃ§Ã£o 
    ?>
    <?php $paginacao->config_paginacao();// Chama a funÃ§Ã£o de paginaÃ§Ã£o da class paginacao() ?>          
                       
   </div>
  </div>  
   <?php
   //fim case 11
   break; 
   ?>
   
   
   <?php
   case 12: //FUNÃ‡ÃƒO RELATÃ“RIO FUNCIONARIOS
   ?>
   <div class="templatemo-flex-row flex-content-row">
            
   <div class="templatemo-content-widget white-bg col-2">
              <!-- i class="fa fa-times"></i -->
              <!-- div class="square"></div -->
    <?php echo "teste content pag Relatorios funcionÃ¡rios"; ?>          
                       
   </div>
  </div>  
   <?php
   //fim case 12
   break; 
   ?>
   
   
   <?php
   case 13: //FUNÃ‡ÃƒO CADASTRA ATIVIDADES
   ?>
   <div class="templatemo-flex-row flex-content-row">
            
   <div class="templatemo-content-widget white-bg col-2">
              <!-- i class="fa fa-times"></i -->
              <!-- div class="square"></div -->
        <?php	
	     //Limpa os campos se carregados pÃ³s aleraÃ§Ã£o
		   include("func_convert_data.php");
		   if(empty($_GET["id_ativ"]))
		   {
			$_SESSION["id_ativ"]    = ""; 
			$_SESSION["nome_ativ"]  = ""; 
			$_SESSION["id_func"]    = ""; 
			$_SESSION["valor"]      = "";
			$_SESSION["status_pl"]  = "";
			$_SESSION["nome_func"]  = "";
			$_SESSION["titulo_tb"]  = "INCLUSÃƒO DE ATIVIDADES";  
		   }
		   ?>
           <?php 
		   include("func_select_option.php");
		   include("../Controle/class_se_existe.php");
		   $se_existe = new se_existe();
		   include("../Modelo/sql_existe_atividade.php");
           $se_existe->se_existe_ativ();
		   
           if(isset($se_existe->res_conf["id_ativ"]))
		   {
			 
			$_SESSION["id_ativ"]     = $se_existe->res_conf["id_ativ"]; 
			$_SESSION["nome_ativ"]   = $se_existe->res_conf["nome_ativ"];
			$_SESSION["id_func"]     = $se_existe->res_conf["id_func"]; 
			$_SESSION["valor"]       = $se_existe->res_conf["valor"];
			$_SESSION["status_pl"]   = $se_existe->res_conf["status_pl"];
			$_SESSION["nome_func"]   = $se_existe->res_conf["nome_func"];
			$_SESSION["titulo_tb"]   = "ALTERAÃ‡ÃƒO DE ATIVIDADE";  
		   }
		   ?>
        <form name="form1" action="../Controle/class_add_ativ.php" enctype="multipart/form-data" method="post">
        <input type="hidden" name="t_id_ativ" value="<?php echo $_SESSION["id_ativ"]; ?>" size="12" maxlength="10" />
        <table width="850" border="0" >
         <tr>
         <td style="font-weight:bold;"><?php echo $_SESSION["titulo_tb"]; ?></td>
         <td align="right">
         <?php echo @$_SESSION["msg"]; @$_SESSION["msg"] = "";?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         <a href="../Visao/index.php?active4=active&page=3&fun=14" target="_parent">
         <img src="../Visao/images/buttons/Sair_over.png" width="26" height="26" title= "Voltar"></a></td>
         </tr>
        </table>
        <br/>
        <table width="500" class="table table-striped table-bordered">
         <tr>
         <td>Atividade:<br /><input type="texto" name="t_nome_ativ" value="<?php echo $_SESSION["nome_ativ"]; ?>" size="40" maxlength="60" 
         required="required" />
         </td>
         <td>Valor<br /><input type="texto" name="t_valor_ativ" value="<?php echo $_SESSION["valor"]; ?>" size="12" maxlength="10" 
         required="required" onkeypress="return formatar_moeda(this,',','.',event);"   />
         </td>
         </tr>
         <tr>
         <td>Professor:<br />
         <select name="t_id_func" required>
         <option value="<?php echo $_SESSION["id_func"]; ?>" 
         selected="selected" style="font-weight:bold; text-decoration:underline;"><?php echo $_SESSION["nome_func"]; ?></option>
         
         <?php 
		   $sql = mysql_query("SELECT * FROM tb_func");
			while ($row_1= mysql_fetch_array($sql)) {
             $sid_func   = $row_1['id_func'];
			 $snome_func = $row_1['nome_func'];
             echo"<option value='$sid_func'>$snome_func</option>";
			}
		 ?>
         </select>
         </td>
         <td>Tipo cobranÃ§a:</br>
         <select name="t_status_pl" required>
         <option value="<?php echo $_SESSION["status_pl"]; ?>" selected="selected" style="font-weight:bold; text-decoration:underline;"><?php echo $_SESSION["status_pl"]; ?></option>
         <option value="MEN">Mensal</option>
         <option value="TRI">Trimestral</option>
         <option value="TAX">Taxas de cobranÃ§a</option>
         </select>
         </td>
         </tr>
        </table>
        <br />
        <table width="850" border="0" >
         <tr>
         <td>
         <button type="submit" class="templatemo-blue-button width-10" name="bt_func_grava" onclick="return confirm('Confirma os dados?')"/>
         Gravar</button>
         </td>
         <td width="273" style="color:#F00;">&nbsp;
	     
          </td>
          </tr>
        </table>
	       
                       
   </div>
  </div>  
   <?php
   //fim case 13
   break; 
   ?>
   
   
   <?php
   case 14: //FUNÃ‡ÃƒO CONSULTA ATIVIDADES
   ?>
   <div class="templatemo-flex-row flex-content-row">
            
   <div class="templatemo-content-widget white-bg col-2">
              <!-- i class="fa fa-times"></i -->
              <!-- div class="square"></div -->
    <?php 
	include("func_convert_data.php");
    include("class_pag_con_ativ.php");
    ?>          
    <?php
    //Chamo a classe
    $paginacao = new paginacao();
    $paginacao->qtn = 6;// determina a quantidade de elementos na barra de navegaÃ§Ã£o
    $paginacao->ttpg = 6;// total de registros por pÃ¡gina
    $paginacao->pg = @$_GET["pg"];

    include("../Modelo/sql_paginacao_pesq_e_ord_ativ.php"); //Chama SQL de pesquisa e ordenaÃ§Ã£o para paginaÃ§Ã£o 
    ?>
    <?php $paginacao->config_paginacao();// Chama a funÃ§Ã£o de paginaÃ§Ã£o da class paginacao() ?>          
                       
   </div>
  </div>  
   <?php
   //fim case 14
   break; 
   ?>
   
   
   <?php
   case 15: //FUNÃ‡ÃƒO CADASTRAR GRADE ATIVIDADES
   ?>
   <div class="templatemo-flex-row flex-content-row">
            
   <div class="templatemo-content-widget white-bg col-2">
              <!-- i class="fa fa-times"></i -->
              <!-- div class="square"></div -->
     <?php	
	     //Limpa os campos se carregados pÃ³s aleraÃ§Ã£o
		   include("func_convert_data.php");
		   if(empty($_GET["id_ativ_gd"]))
		   {
			$_SESSION["id_ativ_gd"] = ""; 
			$_SESSION["id_ativ"]    = ""; 
			$_SESSION["id_func"]    = ""; 
			$_SESSION["id_sem"]     = "";
			$_SESSION["hora_ini"]   = "";	
			$_SESSION["hora_fim"]   = "";	
			$_SESSION["titulo_tb"]  = "INCLUSÃƒO DE GRADE DE ATIVIDADES";  
		   }
		   ?>
           <?php 
		   include("func_select_option.php");
		   include("../Controle/class_se_existe.php");
		   $se_existe = new se_existe();
		   include("../Modelo/sql_existe_atividade_gd.php");
           $se_existe->se_existe_ativ_gd();
		   
           if(isset($se_existe->res_conf["id_ativ_gd"]))
		   { 
			$_SESSION["id_ativ_gd"] = $se_existe->res_conf["id_ativ_gd"]; 
			$_SESSION["id_ativ"]    = $se_existe->res_conf["id_ativ"]; 
			$_SESSION["id_func"]    = $se_existe->res_conf["id_func"];
			$_SESSION["id_sem"]     = $se_existe->res_conf["id_sem"]; 
			$_SESSION["hora_ini"]   = $se_existe->res_conf["hora_ini"];
			$_SESSION["hora_fim"]   = $se_existe->res_conf["hora_fim"];
			$_SESSION["titulo_tb"]  = "ALTERAÃ‡ÃƒO DE GRADE DE ATIVIDADE";  
		   }
		   ?>
        <form name="form1" action="../Controle/class_add_ativ_gd.php" enctype="multipart/form-data" method="post">
        <input type="hidden" name="t_id_ativ_gd" value="<?php echo $_SESSION["id_ativ_gd"]; ?>" size="12" maxlength="10" />
        <table width="850" border="0" >
         <tr>
         <td style="font-weight:bold;"><?php echo $_SESSION["titulo_tb"]; ?></td>
         <td align="right">
         <?php echo @$_SESSION["msg"]; @$_SESSION["msg"] = "";?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         <a href="../Visao/index.php?active4=active&page=3&fun=16&t_ord=G.id_sem" target="_parent">
         <img src="../Visao/images/buttons/Sair_over.png" width="26" height="26" title= "Voltar"></a>
         </td>
         </tr>
        </table>
        <br/>
        <table width="500" class="table table-striped table-bordered">
         <tr>
         
         <td>
         Atividade:<br /><select name="t_id_ativ" required>
         <?php 
		   $sql = mysql_query("SELECT * FROM tb_atividade");
			while ($row_1= mysql_fetch_array($sql)) {
             $sid_ativ   = $row_1['id_ativ'];
			 $snome_ativ = $row_1['nome_ativ'];
             echo"<option value='$sid_ativ'>$snome_ativ</option>";
			 if($_SESSION["id_ativ"] == "$sid_ativ"){$_SESSION["nome_ativ"] = "$snome_ativ";}
			}
		 ?>
         <option value="<?php echo $_SESSION["id_ativ"]; ?>" 
         selected="selected" style="font-weight:bold; text-decoration:underline;"><?php echo $_SESSION["nome_ativ"]; ?></option>
         </select>
         
         </td>
         <td>Semana:
         <br />
         <select name="t_id_sem" required>
         <?php 
		   $sql = mysql_query("SELECT * FROM tb_sem");
			while ($row_1= mysql_fetch_array($sql)) {
             $sid_sem   = $row_1['id_sem'];
			 $snome_sem = $row_1['nome_sem'];
             echo"<option value='$sid_sem'>$snome_sem</option>";
			 if($_SESSION["id_sem"] == "$sid_sem"){ $_SESSION["nome_sem"] = "$snome_sem";}
			}
		 ?>
         <option value="<?php echo $_SESSION["id_sem"]; ?>" 
         selected="selected" style="font-weight:bold; text-decoration:underline;"><?php echo $_SESSION["nome_sem"]; ?></option>
         </select>
         </td>
         </tr>
         
         <tr>
         <td>
         Hora inicio:<br/>
         <input type="text" name="t_hora_ini" size="10" value="<?php echo $_SESSION["hora_ini"]; ?>" />
         </td>
         <td>
         Hora fim:<br/>
         <input type="text" name="t_hora_fim" size="10" value="<?php echo $_SESSION["hora_fim"]; ?>" />
         </td>
        
         </tr>
        </table>
        <br />
        
        <table width="850" border="0" >
         <tr>
         <td>
         <button type="submit" class="templatemo-blue-button width-10" name="bt_func_grava" onclick="return confirm('Confirma os dados?')"/>
         Gravar</button>
         </td>
         <td width="273" style="color:#F00;">&nbsp;
	     
          </td>
          </tr>
        </table>         
                       
   </div>
  </div>  
   <?php
   //fim case 15
   break; 
   ?>
   <?php
   case 16: //FUNÃ‡ÃƒO CONSULTAR GRADE ATIVIDADES
   ?>
   <div class="templatemo-flex-row flex-content-row">
            
   <div class="templatemo-content-widget white-bg col-2">
              <!-- i class="fa fa-times"></i -->
              <!-- div class="square"></div -->
    <?php 
	include("func_convert_data.php");
	include("func_select_option.php");
    include("class_pag_con_ativ_gd.php");
    ?>          
    <?php
    //Chamo a classe
    $paginacao = new paginacao();
    $paginacao->qtn = 6;// determina a quantidade de elementos na barra de navegaÃ§Ã£o
    $paginacao->ttpg = 6;// total de registros por pÃ¡gina
    $paginacao->pg = @$_GET["pg"];

    include("../Modelo/sql_paginacao_pesq_e_ord_ativ_gd.php"); //Chama SQL de pesquisa e ordenaÃ§Ã£o para paginaÃ§Ã£o 
    ?>
    <?php $paginacao->config_paginacao();// Chama a funÃ§Ã£o de paginaÃ§Ã£o da class paginacao() ?>                
                       
   </div>
  </div>  
   <?php
   //fim case 16
   break; 
   ?>
   <?php
   case 17: //FUNÃ‡ÃƒO CADASTRAR MATRICULAS
   ?>
   <div class="templatemo-flex-row flex-content-row">
            
   <div class="templatemo-content-widget white-bg col-2">
              <!-- i class="fa fa-times"></i -->
              <!-- div class="square"></div -->
    <?php	
	     //Limpa os campos se carregados pÃ³s aleraÃ§Ã£o
		   include("func_convert_data.php");
		   if(empty($_GET["id_mat"]))
		   {
			$_SESSION["id_mat"]     = ""; 
			$_SESSION["mat_alu"]    = ""; 
			$_SESSION["id_alu"]     = ""; 
			$_SESSION["dt_insc"]    = "";	
			$_SESSION["status_pl"]  = "";
			$_SESSION["situacao"]   = "";
			$_SESSION["titulo_tb"]  = "INCLUSÃƒO DE MATRICULAS E ATIVIDADES";  
		   }
		   ?>
           <?php 
		   include("func_convert_id_aluno.php");
		   include("func_convert_id_ativ.php");
		   include("func_select_option.php");
		   include("../Controle/class_se_existe.php");
		   $se_existe = new se_existe();
		   
		   include("../Modelo/sql_existe_matricula.php");
           $se_existe->se_existe_matricula();
		   
           if(isset($se_existe->res_conf["id_mat"]))
		   { 
			$_SESSION["id_mat"]     = $se_existe->res_conf["id_mat"]; 
			$_SESSION["mat_alu"]    = $se_existe->res_conf["mat_alu"]; 
			$_SESSION["id_alu"]     =  $se_existe->res_conf["id_alu"];
			$_SESSION["dt_insc"]    = $se_existe->res_conf["dt_insc"];
			$_SESSION["status_pl"]  = $se_existe->res_conf["status_pl"];
			$_SESSION["situacao"]   = $se_existe->res_conf["situacao"];
			$_SESSION["titulo_tb"]  = "CONSULTAR ATIVIDADES MATRICULADAS";  
		   }
		   ?> 
           <table width="500" >
               <tr>
                <td style="font-weight:bold;"><?php echo $_SESSION["titulo_tb"]; ?><br/><br/></td>
               </tr>
               <tr>
               <td>
               <?php echo @$_SESSION["msg"]; @$_SESSION["msg"] = ""; ?>
               </td>
               </tr>
           </table>  
               
           <br/>
           <?php
		     ///////CRIA MATRICULA E PLANO DE PAGAMENTO//////////////////
		     $recebe_pl = $_GET["t_sel"];       
			 if($recebe_pl == ""){
		  ?>         
              
              <form  name="form1" action="../Controle/class_add_matricula.php" method="post"  enctype="multipart/form-data">
              <input type="hidden" name="t_id_mat" value="<?php echo $_SESSION["id_mat"]; ?>" size="12" maxlength="10" />
              <table width="500" class="table table-striped table-bordered">
              <tr>
              <td>
              Plano de pagamento:<br/>
              <select name="t_status_pl" required>
              <option value="">-- Selecione o plano --</option>
              <option value="AVU">Avulso</option>
              <option value="MEN">Mensal</option>
              <option value="TRI">Trimestral</option>
              </select>
              </td>
              <td>
              Data de inscriÃ§Ã£o:<br/>
              <input type="text"  name="t_dt_insc" value="<?php echo $_SESSION["dt_insc"]; ?>" size="10" maxlength="10"  required/>
              <?php //echo date("d/m/Y"); ?>
              </td>
              </tr>
              <tr>
              <td>
              Nome do aluno:<br />
             <select name="t_id_alu"  />
             <option value="">-- Selecione o aluno --</option>
              <?php 
			   $sql =  mysql_query("SELECT * FROM tb_aluno ORDER BY nome_alu ASC"); 
			   while ($row_1 = mysql_fetch_array($sql)) {
               $sid_alu   = $row_1['id_aluno'];
			   $snome_alu = $row_1['nome_alu'];
               echo "<option value='$sid_alu'>$snome_alu</option>";
			   //if($_SESSION["id_alu"] == "$sid_alu"){ $_SESSION["nome_alu"] = "$snome_alu";} 
			   }
		      ?>
              </select>
              </td>
              <td>&nbsp;
              
              </td>
              </tr>
              </table>
              <br/>
              <input type="submit" value="Gerar MatrÃ­cula" name="bt_gera_mat"/>
              </form>
             <?php
			 }
			 ///////////FIM CRIA MATRICULA E PLANO DE PAGAMENTO///////// 
			////////////////////////////////////////////////////////////
			
			
			
//////////////SELECIONA ATIVIDADES PARA A MATRICULA GERADA CASO TRIMESTAL OU BIMESTRAL ////////////////// 
            
			 
			 if($recebe_pl == "MEN" or $recebe_pl == "TRI" ){

      ////////////MOSTRA A CONSULTA/SELEÃ‡ÃƒO SEM STATUS DE PAFGAMENTO = P ////////////////////
print $status_res = @$_GET["status_pg"]; 

//if($status_res == ""){
	
				if(!empty($_SESSION["passa_matricula"]) ){	
				
				$_SESSION["passa_matricula"];
				$nome_aluno = converte_nome($_SESSION["id_alu"]);
				echo "
				<table width='500' border='0' cellspacing='0' cellpadding='0' class='table table-striped table-bordered'>
                <tr>
                <td>
                 Matricula:&nbsp;$_SESSION[passa_matricula]
				 <br/>
                 Aluno.......:&nbsp;$_SESSION[passa_nomeAluno] 
                </td>
                </tr>
                </table>
                <hr />
                <b>Adicionar atividades:</b>
				<br/><br/>
				
				<form  name='form2' action='../Controle/class_add_matricula_ativ.php' method='post'  enctype='multipart/form-data'>
				<input type='hidden' name='t_mat_alu' value='$_SESSION[passa_matricula]' />
				<input type='hidden' name='t_nome_alu' value='$_SESSION[passa_idAluno]' />
				<input type='hidden' name='t_status_pl' value='$_GET[t_sel]' />
                <table width='500' border='0' cellspacing='0' cellpadding='0' class='table table-striped table-bordered'>
                <tr>
                <td>
                Atividade:<br/>
				<select name='t_id_ativ' required/>
                <option value=''>-- Selecione a atividade --</option>";
			    $sql2 = mysql_query("SELECT * FROM tb_atividade WHERE status_pl = '$_GET[t_sel]' ORDER BY nome_ativ ASC");
				while ($row_2 = mysql_fetch_array($sql2)) {
                $sid_ativ   = $row_2['id_ativ'];
			    $snome_ativ = $row_2['nome_ativ'];
                echo"<option value='$sid_ativ'>$snome_ativ</option>";
			   //if($_SESSION['id_alu'] == '$sid_alu'){ $_SESSION['nome_alu'] = '$snome_alu';} 
			   }
              echo"</select>";
              echo"</td>
                <td>
                Desconto:<br/>
				<input type='text' name='t_id_desc' value='' size='5' maxlength='50' />
                </td>
                <td align='right'><br/>
                 <input type='submit' name='bt_inc' value='Gravar' />
                </td>
                </tr>
                </table>
				</form>
				<br/>
				
				<b>Atividades selecionadas:</b><br/><br/>
                <table width='500' border='0' cellspacing='0' cellpadding='0' class='table table-striped table-bordered'>
                <tr>
                <td width='358'>Atividade</td>
                <td width='124'>Valor</td>
                <td width='126'>Desc.</td>
                <td width='125'>Valor parc.</td>
				<td width='125'>Excluir</td>
                </tr>
				</table>
				<table width='500' border='0' cellspacing='0' cellpadding='0' class='table table-striped table-bordered'>";
                $sql3    = mysql_query("SELECT * FROM tb_matricula_ativ WHERE mat_alu = '$_SESSION[passa_matricula]'");
				$sqlSoma = mysql_query("SELECT SUM(valor_p) as valor_p , mat_alu FROM tb_matricula_ativ WHERE mat_alu = '$_SESSION[passa_matricula]'");
				while($row3 = mysql_fetch_array($sql3)){
				echo"<tr>";
                echo"<td width='358'>".converte_nome_ativ($row3["id_ativ"])."</td>";
                echo"<td width='124'>R$&nbsp;".$row3["valor_ativ"]."</td>";
                echo"<td width='126'>R$&nbsp;".$row3["desconto"]."</td>";
                echo"<td width='125'>R$&nbsp;".$row3["valor_p"]."</td>";
				echo"<td width='125'>"."X"."</td>";
				echo"</tr>";
				}
				echo"
				</table>
                <table width='500' border='0' cellspacing='0' cellpadding='0' class='table table-striped table-bordered'>
                <tr align='right'>
                <td>Valor total:<br/>R$&nbsp;";
				$rowSoma = mysql_fetch_array($sqlSoma);
				echo "<font color='#FF0000'>".$rowSoma["valor_p"]."</font>";
				echo"
				</td>
                </tr>
                <tr>";
				$sqlOn = mysql_query("SELECT * FROM tb_pagamento WHERE mat_alu = '$_SESSION[passa_matricula]'");
				$rowOn = mysql_fetch_array($sqlOn);
				
				if(!$rowOn["mat_alu"] == $_SESSION["passa_matricula"]){
				echo"
                <td>
				<form name='form3' action='../Controle/class_add_pagamento.php' method='post'  enctype='multipart/form-data'>
			
				 <input type='hidden' name='t_status_pl' value='$_GET[t_sel]' />
				 <input type='hidden' name='t_mat_alu'  value='$_SESSION[passa_matricula]' />				
                 <input type='hidden' name='t_id_alu'   value='$_SESSION[passa_idAluno]' />
                 <input type='hidden' name='t_status_pg'   value='P' />
                 <input type='hidden' name='t_dt_venc'  value='";echo date('d/m/Y');echo"' />
                 <input type='hidden' name='t_dt_pag'   value='";echo date('d/m/Y');echo"' />
                 <input type='hidden' name='t_multa'    value='' />
                 <input type='hidden' name='t_valor_t'  value='$rowSoma[valor_p]' />
				 <input type='submit' name='bt_inc2' value='Ativar pagamento de matricula' style='color:#F00; font-weight:bold;' />
				</form>
				</td>
				";
				}
				
				echo"
                </tr>
                </table>
				";
				if($rowOn["mat_alu"] == $_SESSION["passa_matricula"]){
				 echo "
				 <br>
				 <input type='submit' name='bt_inc2' value='Excluir matricula' style='color:#F00; font-weight:bold; margin-right:15pt;' />
				 ";
				}
				
				}
//}	
				/////////////////////////////////////////////////////////////////////////////////////
				
				//////MOSTRA CONSULTA/SELEÃ‡ÃƒO COM STATUS DE PAFGAMENTO = P STATUS ///////////////////////////////////////////
if(!$status_res == ""){				
				if(isset($_GET["id_mat"]) )
				{
				 //$_SESSION["passa_matricula"];
				echo "
				<table width='500' border='0' cellspacing='0' cellpadding='0' class='table table-striped table-bordered'>
                <tr>
                <td>
                 Matricula:&nbsp;$_SESSION[mat_alu]
				 <br/>
                 Aluno.......:&nbsp;"; echo converte_nome($_SESSION["id_alu"]);
                echo"
				</td>
                </tr>
                </table>
                <hr />
               <b>Adicionar atividades:</b>
				
				<br/><br/>
				
				<form  name='form2' action='../Controle/class_add_matricula_ativ_alt.php' method='post'  enctype='multipart/form-data'>
				<input type='hidden' name='t_mat_alu' value='$_SESSION[mat_alu]' />
				<input type='hidden' name='t_nome_alu' value='";echo converte_nome($_SESSION["id_alu"]); echo" ' />
				<input type='hidden' name='t_status_pl' value='$_GET[t_sel]' />
                <table width='500' border='0' cellspacing='0' cellpadding='0' class='table table-striped table-bordered'>
                <tr>
                <td>
                Atividade:<br/>
				<select name='t_id_ativ' required/>
                <option value=''>-- Selecione a atividade --</option>";
			    $sql2 = mysql_query("SELECT * FROM tb_atividade WHERE status_pl = '$_GET[t_sel]' ORDER BY nome_ativ ASC");
				while ($row_2 = mysql_fetch_array($sql2)) {
                $sid_ativ   = $row_2['id_ativ'];
			    $snome_ativ = $row_2['nome_ativ'];
                echo"<option value='$sid_ativ'>$snome_ativ</option>";
			   //if($_SESSION['id_alu'] == '$sid_alu'){ $_SESSION['nome_alu'] = '$snome_alu';} 
			   }
              echo"</select>";
              echo"</td>
                <td>
                Desconto:<br/>
				<input type='text' name='t_id_desc' value='' size='5' maxlength='50' />
                </td>
                <td align='right'><br/>
                 <input type='submit' name='bt_inc' value='Gravar' />
                </td>
                </tr>
                </table>
				</form>
				<br/>
				
				<b>Atividades selecionadas:</b><br/><br/>
                <table width='500' border='0' cellspacing='0' cellpadding='0' class='table table-striped table-bordered'>
                <tr>
                <td width='358'>Atividade</td>
                <td width='124'>Valor</td>
                <td width='126'>Desc.</td>
                <td width='125'>Valor parc.</td>
				<td width='125'>Excluir</td>
                </tr>
				</table>
				<table width='500' border='0' cellspacing='0' cellpadding='0' class='table table-striped table-bordered'>";
                $sql3    = mysql_query("SELECT * FROM tb_matricula_ativ WHERE mat_alu = '$_SESSION[mat_alu]'");
				$sqlSoma = mysql_query("SELECT SUM(valor_p) as valor_p , mat_alu FROM tb_matricula_ativ WHERE mat_alu = '$_SESSION[mat_alu]'");
				while($row3 = mysql_fetch_array($sql3)){
				echo"<tr>";
                echo"<td width='358'>".converte_nome_ativ($row3["id_ativ"])."</td>";
                echo"<td width='124'>R$&nbsp;".$row3["valor_ativ"]."</td>";
                echo"<td width='126'>R$&nbsp;".$row3["desconto"]."</td>";
                echo"<td width='125'>R$&nbsp;".$row3["valor_p"]."</td>";
				echo"<td width='125'>"."X"."</td>";
				echo"</tr>";
				}
				
				echo"
                </table>
                <table width='500' border='0' cellspacing='0' cellpadding='0' class='table table-striped table-bordered'>
                <tr align='right'>
                <td>Valor total:<br/>R$&nbsp;";
				$rowSoma = mysql_fetch_array($sqlSoma);
				echo "<font color='#FF0000'>".$rowSoma["valor_p"]."</font>";
				echo"
				</td>
                </tr>
                <tr>";
				$sqlOn2 = mysql_query("SELECT * FROM tb_pagamento WHERE mat_alu = '$_SESSION[mat_alu]'");
				$rowOn2 = mysql_fetch_array($sqlOn2);
				if(!$rowOn2["mat_alu"] == $_SESSION[mat_alu]){
				echo"
                <td>
				<form name='form3' action='../Controle/class_add_pagamento.php' method='post'  enctype='multipart/form-data'>
				 <input type='text' name='t_status_pl' value='$_GET[t_sel]' />
				 <input type='hidden' name='t_mat_alu'  value='$_SESSION[mat_alu]' />				
                 <input type='hidden' name='t_id_alu'   value='$_SESSION[id_alu]' />
                 <input type='hidden' name='t_status_pg'   value='P' />
                 <input type='hidden' name='t_dt_venc'  value='";echo date('d/m/Y');echo"' />
                 <input type='hidden' name='t_dt_pag'   value='";echo date('d/m/Y');echo"' />
                 <input type='hidden' name='t_multa'    value='' />
                 <input type='hidden' name='t_valor_t'  value='$rowSoma[valor_p]' />
				 <input type='submit' name='bt_inc2' value='Ativar pagamento de matricula' style='color:#F00; font-weight:bold;' />
				</form>
				</td>
				";
				}
				
				echo"
                </tr>
                </table>
				";
				if($rowOn2["mat_alu"] == $_SESSION[mat_alu]){
				 echo"
				 <br>
				 <input type='submit' name='bt_inc2' value='Excluir matricula' style='color:#F00; font-weight:bold; margin-right:15pt;' />
				 ";
				 
				}
			
			  }
}
				
			 //////////////////////////////////////////////////////////////////////
			 
}
////////////////////FIM SELEÃ‡ÃƒO CASO TRIMESTAL OU BIMESTRAL ///////////////////////
							
				


//////////////SELECIONA ATIVIDADES PARA A MATRICULA GERADA CASO AVULSO //////////// 
				
				if($recebe_pl == "AVU"){
				////////////MOSTRA A CONSULTA/SELEÃ‡ÃƒO SEM STATUS DE PAFGAMENTO = P ////////////////////
$status_res = @$_GET["status_pg"]; 

//if($status_res == ""){
	
				if(!empty($_SESSION["passa_matricula"]) ){	
				
				$_SESSION["passa_matricula"];
				$nome_aluno = converte_nome($_SESSION["id_alu"]);
				echo "
				<table width='500' border='0' cellspacing='0' cellpadding='0' class='table table-striped table-bordered'>
                <tr>
                <td>
                 Matricula:&nbsp;$_SESSION[passa_matricula]
				 <br/>
                 Aluno.......:&nbsp;$_SESSION[passa_nomeAluno] 
                </td>
                </tr>
                </table>
                <hr />
                <b>Adicionar atividades:</b>
				<br/><br/>
				
				<form  name='form2' action='../Controle/class_add_matri_ativ_avu.php' method='post'  enctype='multipart/form-data'>
				<input type='hidden' name='t_mat_alu' value='$_SESSION[passa_matricula]' />
				<input type='hidden' name='t_nome_alu' value='$_SESSION[passa_idAluno]' />
				<input type='hidden' name='t_status_pl' value='$_GET[t_sel]' />
				<input type='hidden' name='t_status_pg' value='$_GET[status_pg]' />
                <table width='500' border='0' cellspacing='0' cellpadding='0' class='table table-striped table-bordered'>
                <tr>
                <td>
                Atividade:<br/>
				<select name='t_id_ativ' required/>
                <option value=''>-- Selecione a atividade --</option>";
			    $sql2 = mysql_query("SELECT * FROM tb_atividade ORDER BY nome_ativ ASC");
				while ($row_2 = mysql_fetch_array($sql2)) {
                $sid_ativ   = $row_2['id_ativ'];
			    $snome_ativ = $row_2['nome_ativ'];
                echo"<option value='$sid_ativ'>$snome_ativ</option>";
			   //if($_SESSION['id_alu'] == '$sid_alu'){ $_SESSION['nome_alu'] = '$snome_alu';} 
			   }
              echo"</select>";
              echo"</td>
                <td>
				<br/>
                Desconto:
				<input type='text' name='t_id_desc' value='' size='5' maxlength='50' />
				&nbsp;&nbsp;Valor da atividade:
				<input type='text' name='t_valor_p' value='' size='5' maxlength='50' required />
                </td>
                <td align='right'><br/>
                 <input type='submit' name='bt_inc' value='Gravar' />
                </td>
                </tr>
                </table>
				</form>
				<br/>
				
				<b>Atividades selecionadas:</b><br/><br/>
                <table width='500' border='0' cellspacing='0' cellpadding='0' class='table table-striped table-bordered'>
                <tr>
                <td width='358'>Atividade</td>
                <td width='124'>Valor</td>
                <td width='126'>Desc.</td>
                <td width='125'>Valor parc.</td>
				<td width='125'>Excluir</td>
                </tr>
				</table>
				<table width='500' border='0' cellspacing='0' cellpadding='0' class='table table-striped table-bordered'>";
                $sql3    = mysql_query("SELECT * FROM tb_matricula_ativ WHERE mat_alu = '$_SESSION[passa_matricula]'");
				$sqlSoma = mysql_query("SELECT SUM(valor_p) as valor_p , mat_alu FROM tb_matricula_ativ WHERE mat_alu = '$_SESSION[passa_matricula]'");
				while($row3 = mysql_fetch_array($sql3)){
				echo"<tr>";
                echo"<td width='358'>".converte_nome_ativ($row3["id_ativ"])."</td>";
                echo"<td width='124'>R$&nbsp;".$row3["valor_ativ"]."</td>";
                echo"<td width='126'>R$&nbsp;".$row3["desconto"]."</td>";
                echo"<td width='125'>R$&nbsp;".$row3["valor_p"]."</td>";
				echo"<td width='125'>"."X"."</td>";
				echo"</tr>";
				}
				echo"
				</table>
                <table width='500' border='0' cellspacing='0' cellpadding='0' class='table table-striped table-bordered'>
                <tr align='right'>
                <td>Valor total:<br/>R$&nbsp;";
				$rowSoma = mysql_fetch_array($sqlSoma);
				echo "<font color='#FF0000'>".$rowSoma["valor_p"]."</font>";
				echo"
				</td>
                </tr>
                <tr>";
				$sqlOn = mysql_query("SELECT * FROM tb_pagamento WHERE mat_alu = '$_SESSION[passa_matricula]'");
				$rowOn = mysql_fetch_array($sqlOn);
				
				if(!$rowOn["mat_alu"] == $_SESSION["passa_matricula"]){
				echo"
                <td>
				<form name='form3' action='../Controle/class_add_pagamento_avu.php' method='post'  enctype='multipart/form-data'>
				 <input type='hidden' name='t_status_pl' value='$_GET[t_sel]' />
				 <input type='hidden' name='t_mat_alu'  value='$_SESSION[passa_matricula]' />				
                 <input type='hidden' name='t_id_alu'   value='$_SESSION[passa_idAluno]' />
                 <input type='hidden' name='t_status_pg'   value='P' />
                 <input type='hidden' name='t_dt_venc'  value='";echo date('d/m/Y');echo"' />
                 <input type='hidden' name='t_dt_pag'   value='";echo date('d/m/Y');echo"' />
                 <input type='hidden' name='t_multa'    value='' />
                 <input type='hidden' name='t_valor_t'  value='$rowSoma[valor_p]' />
				 <input type='submit' name='bt_inc2' value='Ativar pagamento de matricula' style='color:#F00; font-weight:bold;' />
				</form>
				</td>
				";
				}
				
				echo"
                </tr>
                </table>
				";
				if($rowOn["mat_alu"] == $_SESSION["passa_matricula"]){
				 echo "
				 <br>
				 <input type='submit' name='bt_inc2' value='Excluir matricula' style='color:#F00; font-weight:bold; margin-right:15pt;' />
				 ";
				}
				
				}
//}	
				/////////////////////////////////////////////////////////////////////////////////////
				
				//////MOSTRA CONSULTA/SELEÃ‡ÃƒO SEM STATUS ///////////////////////////////////////////
if(!$status_res == ""){				
				if(isset($_GET["id_mat"]) )
				{
				 //$_SESSION["passa_matricula"];
				echo "
				<table width='500' border='0' cellspacing='0' cellpadding='0' class='table table-striped table-bordered'>
                <tr>
                <td>
                 Matricula:&nbsp;$_SESSION[mat_alu]
				 <br/>
                 Aluno.......:&nbsp;"; echo converte_nome($_SESSION["id_alu"]);
                echo"
				</td>
                </tr>
                </table>
                <hr />
               <b>Adicionar atividades:</b>
				
				<br/><br/>
				
				<form  name='form2' action='../Controle/class_add_matri_ativ_avu_alt.php' method='post'  enctype='multipart/form-data'>
				<input type='hidden' name='t_mat_alu' value='$_SESSION[mat_alu]' />
				<input type='hidden' name='t_nome_alu' value='";echo converte_nome($_SESSION["id_alu"]); echo" ' />
				<input type='hidden' name='t_status_pl' value='$_GET[t_sel]' />
				<input type='hidden' name='t_status_pg' value='$_GET[status_pg]' />
                <table width='500' border='0' cellspacing='0' cellpadding='0' class='table table-striped table-bordered'>
                <tr>
                <td>
                Atividade:<br/>
				<select name='t_id_ativ' required/>
                <option value=''>-- Selecione a atividade --</option>";
			    $sql2 = mysql_query("SELECT * FROM tb_atividade ORDER BY nome_ativ ASC");
				while ($row_2 = mysql_fetch_array($sql2)) {
                $sid_ativ   = $row_2['id_ativ'];
			    $snome_ativ = $row_2['nome_ativ'];
                echo"<option value='$sid_ativ'>$snome_ativ</option>";
			   //if($_SESSION['id_alu'] == '$sid_alu'){ $_SESSION['nome_alu'] = '$snome_alu';} 
			   }
              echo"</select>";
              echo"</td>
                <td>
                Desconto:
				<input type='text' name='t_id_desc' value='' size='5' maxlength='50' />
				&nbsp;&nbsp;Valor da atividade:
				<input type='text' name='t_valor_p' value='' size='5' maxlength='50' required />
                </td>
                <td align='right'><br/>
                 <input type='submit' name='bt_inc' value='Gravar' />
                </td>
                </tr>
                </table>
				</form>
				<br/>
				
				<b>Atividades selecionadas:</b><br/><br/>
                <table width='500' border='0' cellspacing='0' cellpadding='0' class='table table-striped table-bordered'>
                <tr>
                <td width='358'>Atividade</td>
                <td width='124'>Valor</td>
                <td width='126'>Desc.</td>
                <td width='125'>Valor parc.</td>
				<td width='125'>Excluir</td>
                </tr>
				</table>
				<table width='500' border='0' cellspacing='0' cellpadding='0' class='table table-striped table-bordered'>";
                $sql3    = mysql_query("SELECT * FROM tb_matricula_ativ WHERE mat_alu = '$_SESSION[mat_alu]'");
				$sqlSoma = mysql_query("SELECT SUM(valor_p) as valor_p , mat_alu FROM tb_matricula_ativ WHERE mat_alu = '$_SESSION[mat_alu]'");
				while($row3 = mysql_fetch_array($sql3)){
				echo"<tr>";
                echo"<td width='358'>".converte_nome_ativ($row3["id_ativ"])."</td>";
                echo"<td width='124'>R$&nbsp;".$row3["valor_ativ"]."</td>";
                echo"<td width='126'>R$&nbsp;".$row3["desconto"]."</td>";
                echo"<td width='125'>R$&nbsp;".$row3["valor_p"]."</td>";
				echo"<td width='125'>"."X"."</td>";
				echo"</tr>";
				}
				
				echo"
                </table>
                <table width='500' border='0' cellspacing='0' cellpadding='0' class='table table-striped table-bordered'>
                <tr align='right'>
                <td>Valor total:<br/>R$&nbsp;";
				$rowSoma = mysql_fetch_array($sqlSoma);
				echo "<font color='#FF0000'>".$rowSoma["valor_p"]."</font>";
				echo"
				</td>
                </tr>
                <tr>";
				$sqlOn2 = mysql_query("SELECT * FROM tb_pagamento WHERE mat_alu = '$_SESSION[mat_alu]'");
				$rowOn2 = mysql_fetch_array($sqlOn2);
				if(!$rowOn2["mat_alu"] == $_SESSION[mat_alu]){
				echo"
                <td>
				<form name='form3' action='../Controle/class_add_pagamento_avu.php' method='post'  enctype='multipart/form-data'>
				 <input type='text' name='t_status_pl' value='$_GET[t_sel]' />
				 <input type='hidden' name='t_mat_alu'  value='$_SESSION[mat_alu]' />				
                 <input type='hidden' name='t_id_alu'   value='$_SESSION[id_alu]' />
                 <input type='hidden' name='t_status_pg'   value='P' />
                 <input type='hidden' name='t_dt_venc'  value='";echo date('d/m/Y');echo"' />
                 <input type='hidden' name='t_dt_pag'   value='";echo date('d/m/Y');echo"' />
                 <input type='hidden' name='t_multa'    value='' />
                 <input type='hidden' name='t_valor_t'  value='$rowSoma[valor_p]' />
				 <input type='submit' name='bt_inc2' value='Ativar pagamento de matricula' style='color:#F00; font-weight:bold;' />
				</form>
				</td>
				";
				}
				
				echo"
                </tr>
                </table>
				";
				if($rowOn2["mat_alu"] == $_SESSION[mat_alu]){
				 echo"
				 <br>
				 <input type='submit' name='bt_inc2' value='Excluir matricula' style='color:#F00; font-weight:bold; margin-right:15pt;' />
				 ";
				 
				}					  
                
				}
					 
}
 //////////////////////////////////////////////////////////////////////	
				
				}
			  ?>
              
           <br/><br/><br/><br/><br/><br/><br/><br/>
          
                                           
   </div>
  </div>  
   <?php
   //fim case 18
   break; 
   ?>  
<?php
   case 18: //FUNÃ‡ÃƒO COLSULTA MATRICULAS
   ?>
   <div class="templatemo-flex-row flex-content-row">
            
   <div class="templatemo-content-widget white-bg col-2">
              <!-- i class="fa fa-times"></i -->
              <!-- div class="square"></div -->
    <?php 
	$_SESSION[passa_matricula] = "";// Zera a variÃ¡vel para gerar a condiÃ§Ã£o de alterar atv. da matricula ou inclusÃ£o de matricula. 
	include("func_convert_data.php");
	include("func_convert_id_aluno.php");
    include("class_pag_con_matricula.php");
    ?>          
    <?php
    //Chamo a classe
    $paginacao = new paginacao();
    $paginacao->qtn = 6;// determina a quantidade de elementos na barra de navegaÃ§Ã£o
    $paginacao->ttpg = 6;// total de registros por pÃ¡gina
    $paginacao->pg = @$_GET["pg"];

    include("../Modelo/sql_paginacao_pesq_e_ord_matricula.php"); //Chama SQL de pesquisa e ordenaÃ§Ã£o para paginaÃ§Ã£o 
    ?>
    <?php $paginacao->config_paginacao();// Chama a funÃ§Ã£o de paginaÃ§Ã£o da class paginacao() ?>
                       
   </div>
  </div>  
   <?php
   //fim case 18
   break; 
   ?>
   <?php
   case 19: //FUNÃ‡ÃƒO RELATORIO MATRICULAS
   ?>
   <div class="templatemo-flex-row flex-content-row">
            
   <div class="templatemo-content-widget white-bg col-2">
              <!-- i class="fa fa-times"></i -->
              <!-- div class="square"></div -->
    <?php echo "teste content pag Relatorios matriculas"; ?>          
                       
   </div>
  </div>  
   <?php
   //fim case 19
   break; 
   ?>
   <?php
   case 20: //SELEÃ‡ÃƒO DE CONSULTAS DE PAGAMENTOS
   ?>
   <div class="templatemo-flex-row flex-content-row">
            
   <div class="templatemo-content-widget white-bg col-2">
              <!-- i class="fa fa-times"></i -->
              <!-- div class="square"></div -->
     <h5 align="center" style="font-weight: bold;">CONSULTA DE PAGAMENTOS:</h5><br/>      
    <table width="600" border="0" cellspacing="0" cellpadding="0" class='table table-striped table-bordered'>
  <tr>
    <td><a href="index.php?active2=active&page=4&fun=201" target="_parent">Pagamentos em Aberto</a></td>
  </tr>
  <tr>
    <td><a href="index.php?active2=active&page=4&fun=202" target="_parent">Pagamentos Trancados</a></td>
  </tr>
  <tr>
    <td><a href="index.php?active2=active&page=4&fun=203" target="_parent">Pagamentos Isentos</a></td> 
  </tr>
</table>
     
                       
   </div>
  </div>  
   <?php
   //fim case 20
   break; 
   ?>
     <?php
   case 201: //CONSULTA DE PAGAMENTOS EM ABERTO
   ?>
   <div class="templatemo-flex-row flex-content-row">
            
   <div class="templatemo-content-widget white-bg col-2">
   <?php 
	include("func_convert_data.php");
    include("class_pag_con_pagamento.php");
    ?>          
    <?php
    //Chamo a classe
    $paginacao = new paginacao();
    $paginacao->qtn = 6;// determina a quantidade de elementos na barra de navegaÃ§Ã£o
    $paginacao->ttpg = 6;// total de registros por pÃ¡gina
    $paginacao->pg = @$_GET["pg"];

    include("../Modelo/sql_paginacao_pesq_e_ord_pagamento.php"); //Chama SQL de pesquisa e ordenaÃ§Ã£o para paginaÃ§Ã£o 
    ?>
    <?php $paginacao->config_paginacao();// Chama a funÃ§Ã£o de paginaÃ§Ã£o da class paginacao() ?>          
                       
   </div>
  </div>  
   <?php
   //fim case 201
   break; 
   ?>
   <?php
   case 202: //CONSULTA DE PAGAMENTOS TRANCADOS
   ?>
   <div class="templatemo-flex-row flex-content-row">
            
   <div class="templatemo-content-widget white-bg col-2">
   <?php 
	include("func_convert_data.php");
    include("class_pag_con_pag_trancado.php");
    ?>          
    <?php
    //Chamo a classe
    $paginacao = new paginacao();
    $paginacao->qtn = 6;// determina a quantidade de elementos na barra de navegaÃ§Ã£o
    $paginacao->ttpg = 6;// total de registros por pÃ¡gina
    $paginacao->pg = @$_GET["pg"];

    include("../Modelo/sql_paginacao_pesq_e_ord_pag_trancado.php"); //Chama SQL de pesquisa e ordenaÃ§Ã£o para paginaÃ§Ã£o 
    ?>
    <?php $paginacao->config_paginacao();// Chama a funÃ§Ã£o de paginaÃ§Ã£o da class paginacao() ?>                             
   </div>
  </div>  
   <?php
   //fim case 202
   break; 
   ?>
   <?php
   case 203: //CONSULTA DE PAGAMENTOS ISENTOS
   ?>
   <div class="templatemo-flex-row flex-content-row">
            
   <div class="templatemo-content-widget white-bg col-2">
   <?php 
	include("func_convert_data.php");
    include("class_pag_con_pag_isento.php");
    ?>          
    <?php
    //Chamo a classe
    $paginacao = new paginacao();
    $paginacao->qtn = 6;// determina a quantidade de elementos na barra de navegaÃ§Ã£o
    $paginacao->ttpg = 6;// total de registros por pÃ¡gina
    $paginacao->pg = @$_GET["pg"];

    include("../Modelo/sql_paginacao_pesq_e_ord_pag_isento.php"); //Chama SQL de pesquisa e ordenaÃ§Ã£o para paginaÃ§Ã£o 
    ?>
    <?php $paginacao->config_paginacao();// Chama a funÃ§Ã£o de paginaÃ§Ã£o da class paginacao() ?>          
                       
   </div>
  </div>  
   <?php
   //fim case 203
   break; 
   ?>
   <?php
   case 21: //CADASTRO DE PAGAMENTOS
   ?>
   <div class="templatemo-flex-row flex-content-row">
            
   <div class="templatemo-content-widget white-bg col-2">
              <!-- i class="fa fa-times"></i -->
              <!-- div class="square"></div -->
    <?php
	include("func_convert_id_ativ.php");
	include("func_convert_id_aluno.php");
    include("func_select_option.php");
	?>
    <table width='500' border='0' cellspacing='0' cellpadding='0' class='table table-striped table-bordered'>
                <?php 
                $sql4 = mysql_query("SELECT * FROM tb_matricula WHERE id_alu=$_GET[id_aluno]");
                $row4_sql = mysql_fetch_array($sql4);
                ?>
                <tr>
                <td>
                <?php echo"Matricula:&nbsp;".$row4_sql["mat_alu"]; ?>
				 <br/>
                <?php echo"Aluno.......:&nbsp;".converte_nome($row4_sql["id_alu"]); ?> 
                </td>
                </tr>
                </table>
                <br/>
    <b>Atividades selecionadas:</b><br/><br/>
                <table width='500' border='0' cellspacing='0' cellpadding='0' class='table table-striped table-bordered'>
                <tr>
                <td width='358'>Atividade</td>
                <td width='124'>Valor</td>
                <td width='126'>Desc.</td>
                <td width='125'>Valor parc.</td>
                </tr>
				</table>
				<table width='500' border='0' cellspacing='0' cellpadding='0' class='table table-striped table-bordered'>
                <?php $sql3    = mysql_query("SELECT * FROM tb_matricula_ativ WHERE mat_alu = '$row4_sql[mat_alu]'");
                $sqlSoma = mysql_query("SELECT SUM(valor_p) as valor_p , mat_alu FROM tb_matricula_ativ WHERE mat_alu = '$row4_sql[mat_alu]'"); 
				while($row3 = mysql_fetch_array($sql3)){ ?>
				<tr>
                <td width='358'><?php echo converte_nome_ativ($row3["id_ativ"]); ?></td>
                <td width='124'><?php echo "R$&nbsp;".$row3["valor_ativ"]; ?></td>
                <td width='126'><?php echo "R$&nbsp;".$row3["desconto"]; ?></td>
                <td width='125'><?php echo "R$&nbsp;".$row3["valor_p"]; ?></td>
				</tr>
                <?php } ?>
                </table>
                <table width='500' border='0' cellspacing='0' cellpadding='0' class='table table-striped table-bordered'>
                <tr align='right'>
                <td><?php echo "Valor total:<br/>R$&nbsp;";
				$rowSoma = mysql_fetch_array($sqlSoma); ?>
				<?php echo "<font color='#FF0000'>".$rowSoma["valor_p"]."</font>"; ?>
				</td>
                </tr>	
                </table>
                <hr />
<table  width='700' border='0' cellspacing='0' cellpadding='0'  >
                <tr>
                <td>Situação:&nbsp;<label></label></td>
                <td>Data de vencimento:&nbsp;<label></label></td>
                <td>Data do último pg:&nbsp;<label></label></td>
                </tr>
                </table>
                <br/>
                <table  width='849' border='0' cellspacing='0' cellpadding='0' >
                <tr>
                <td width="179">
                <?php if($row4_sql['status_pl'] == "MEN" or $row4_sql['status_pl']== "TRI"){ ?>
                <form action="#" method="post" name="form1" enctype="multipart/form-data" />
                Multa:&nbsp;
                <input type="text" name="t_multa" value="" maxlength="10" size="10" /><br /><br /><br/>
                <input type="submit" name="t_bt01" value="Efetuar Pagamento" />
                </form>
                <?php }else{ ?>
                <input type="text" name="t_multa" value="" maxlength="10" size="10" disabled="disabled" /><br /><br /><br/>
                <input type="submit" name="t_bt01" value="Efetuar Pagamento" disabled="disabled" />
				<?php } ?>
                </td>
                <td width="185" >
                <form action="#" method="post" name="form11" enctype="multipart/form-data" />
                &nbsp;
                <input type="hidden" name="t_" value="" maxlength="10" size="10" /><br /><br />
                <input type="submit" name="t_bt011" value="Trancar Pagamento" style="margin-top:26px;" />
                </form>
                </td>
                <td width="174">
                <form action="#" method="post" name="form111" enctype="multipart/form-data" />
                &nbsp;
                <input type="hidden" name="t_" value="" maxlength="10" size="10" /><br /><br />
                <input type="submit" name="t_bt0111" value="Reativar Pagamento" style="margin-top:26px;" />
                </form>
                </td>
                <td width="173">
                <form action="#" method="post" name="form112" enctype="multipart/form-data" />
                &nbsp;
                <input type="hidden" name="t_" value="" maxlength="10" size="10" /><br /><br />
                <input type="submit" name="t_bt0112" value="Isentar Pagamento" style="margin-top:26px;" />
                </form>
                </td>
                <td width="138">
                &nbsp;
                <?php if($row4_sql['status_pl']== "AVU"){ ?>
                <input type="hidden" name="t_" value="" maxlength="10" size="10" /><br /><br />
                <input type="submit" name="t_bt0a1" value="Pagamento Avulso" style="margin-top:26px;" />
                <?php }else{ ?>
                <input type="hidden" name="t_" value="" maxlength="10" size="10" disabled="disabled" /><br /><br />
                <input type="submit" name="t_bt0a1" value="Pagamento Avulso" style="margin-top:26px;" disabled="disabled" />
                <?php } ?>
                </td>
                </tr>
                </table>
                			          
                       
   </div>
  </div>  
   <?php
   //fim case 21
   break; 
   ?>    
     
      
<?php 
//Fim Switch case
}
?>
