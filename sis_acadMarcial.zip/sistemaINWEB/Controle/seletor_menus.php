<?php //session_start(); ?>

<?php 
$n = $_SESSION["permissao"];
$page = 0;
if(isset($_GET["page"])){$page = $_GET["page"];}

switch($page){

  case 0: ?>
       <nav class="templatemo-left-nav">          
            <ul>
              <!--li><a href="index.php?active1=active&page=0&fun=1">Calculadora</a></li -->
              <!-- li><a href="index.php?active1=active&page=0&fun=2">Calendário</a></li -->
              <?php if($n == 3){ ?>
              <li><a href="index.php?active1=active&page=0&fun=3">Criar usuários</a></li>
              <?php }else{ echo "<li><a style='color:#000;'>Criar usuários</a></li>";} ?>
              <?php if($n == 3){ ?>
              <li><a href="index.php?active1=active&page=0&fun=4">Consultar usuários</a></li>
              <?php }else{ echo "<li><a style='color:#000;'>Consultar usuários</a></li>";} ?>
              <!--li><a href="index.php?active1=active&page=0&fun=5">Google maps</a></li -->
              <?php if($n == 3 or $n == 2){ ?>
              <li><a href="index.php?active1=active&page=0&fun=6"></i>Minha conta</a></li>
              <?php }else{ echo "<li><a style='color:#000;'>Minha conta</a></li>";} ?>
              <li><a href="index.php?active1=active&page=0&fun=0">Status</a></li>
              <!--li><a href="login.html">Sair</a></li -->
            </ul>  
        </nav>
  <?php
   //fim case 0
   break;	
   ?>
   <?php
   case 1:
   ?>
   <nav class="templatemo-left-nav">          
            <ul>
              <?php if($n == 3 or $n == 2){ ?>
              <li><a href="index.php?active2=active&page=1&fun=7">Cadastrar alunos</a></li>
              <?php }else{ echo "<li><a style='color:#000;'>Cadastrar alunos</a></li>";} ?>
              <?php if($n == 3 or $n == 2){ ?>
              <li><a href="index.php?active2=active&page=1&fun=8">Consultar alunos</a></li>
              <?php }else{ echo "<li><a style='color:#000;'>Consultar alunos</a></li>";} ?>
              <?php if($n == 3 or $n == 2 or $n == 1){ ?>
              <li><a href="index.php?active2=active&page=1&fun=9">Relatório Alunos</a></li>
              <?php }else{ echo "<li><a style='color:#000;'>Relatório alunos</a></li>";} ?>
              <!--li><a href="manage-users.html">Criar usuários</a></li -->
            </ul>  
        </nav>
   <?php
   break; 
   ?>
   <?php
   case 2:
   ?>
   <nav class="templatemo-left-nav">          
            <ul>
              <?php if($n == 3){ ?>
              <li><a href="index.php?active3=active&page=2&fun=10">Cadastrar funcionários</a></li>
              <?php }else{ echo "<li><a style='color:#000;'>Cadastrar funcionários</a></li>";} ?>
              <?php if($n == 3){ ?>
              <li><a href="index.php?active3=active&page=2&fun=11">Consultar funcionários</a></li>
              <?php }else{ echo "<li><a style='color:#000;'>Consultar funcionários</a></li>";} ?>
              <li><a href="index.php?active3=active&page=2&fun=12">Relatório funcionários</a></li>
              <!--li><a href="manage-users.html">Criar usuários</a></li -->
            </ul>  
        </nav>
   <?php
   break; 
   ?>
   <?php
   case 3:
   ?>
   <nav class="templatemo-left-nav">          
            <ul>
              <?php if($n == 3){ ?>
              <li><a href="index.php?active4=active&page=3&fun=13">Cadastrar atividades</a></li>
              <?php }else{ echo "<li><a style='color:#000;'>Cadastrar atividades</a></li>";} ?>
              <?php if($n == 3){ ?>
              <li><a href="index.php?active4=active&page=3&fun=14">Consultar atividades</a></li>
              <?php }else{ echo "<li><a style='color:#000;'>Consultar atividades</a></li>";} ?>
              <?php if($n == 3){ ?>
              <li><a href="index.php?active4=active&page=3&fun=15">Cadastrar grade de ativ.</a></li>
              <?php }else{ echo "<li><a style='color:#000;'>Cadastrar grade de ativ.</a></li>";} ?>
              <?php if($n == 3){ ?>
              <li><a href="index.php?active4=active&page=3&fun=16&t_ord=G.id_sem">Consultar grade de ativ.</a></li>
              <?php }else{ echo "<li><a style='color:#000;'>Consultar grade de ativ.</a></li>";} ?>
              <li><a href="index.php?active4=active&page=3&fun=15">Relatório atividades e grade</a></li>
              <!--li><a href="manage-users.html">Criar usuários</a></li -->
            </ul>  
        </nav>
   <?php
   break; 
   ?>
   <?php
   case 4:
   ?>
   <nav class="templatemo-left-nav">          
            <ul>
              <?php if($n == 3 or $n == 2){ ?>
              <li><a href="index.php?active5=active&page=4&fun=17">Cadastrar matrículas</a></li>
              <?php }else{ echo "<li><a style='color:#000;'>Cadastrar matrículas</a></li>";} ?>
              <?php if($n == 3 or $n == 2){ ?>
              <li><a href="index.php?active5=active&page=4&fun=18">Consultar matrículas</a></li>
              <?php }else{ echo "<li><a style='color:#000;'>Consultar matrículas</a></li>";} ?>
              <li><a href="index.php?active5=active&page=4&fun=20">Consultar pagamentos</a></li>
              <li><a href="index.php?active5=active&page=4&fun=19">Relatório matrículas</a></li>
              <li><a href="index.php?active5=active&page=4&fun=21">Relatório pagamentos</a></li>
              <!--li><a href="manage-users.html">Criar usuários</a></li-->
            </ul>  
        </nav>
   <?php
   break; 
   ?>
   
   
<?php 
//Fim Switch case
}
?>