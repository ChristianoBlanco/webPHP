<?php 
//session_start();
//error_reporting(0);

//SESSOES que recebem parametros de login_go.php
@$_SESSION["login"];
@$_SESSION["senha"];
@$_SESSION["id_usu"];
@$_SESSION["permissao"];

//$_SESSION["niv_acesso1"];

//Caso login e senha forem vazios, direcionar o usuário p a página de log de erro.
//if(empty($_SESSION["login"]) and empty($_SESSION["senha"])){

// Verifica se existe os dados da sessão de login
if(!isset($_SESSION["login"]) or !isset($_SESSION["id_usu"])){
	
$_SESSION["acao"] = "restrito"; //Mensagem exibição para a pagina erro.php
$_SESSION["msg_log"] = "Login e Senha inexistentes!"; //Mensagem exibição para a pagina erro.php
print "<meta HTTP-EQUIV='Refresh' CONTENT='0;URL=../Visao/erro.php'>"; //Redireciona para a pagina erro.php
exit;
}


?>