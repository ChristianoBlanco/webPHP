
<?php 
session_start();
include("func_convert_data.php");
include("../Modelo/conn_conect.php"); //Conexão com o banco local ou de Intranet.


class add 
{

var $id_usu, $dt_usu, $nome_usu, $login, $senha, $nivel_ac, $ins, $upd, $del, $sel, $sql_ins, $res_ins, $sql_upd, $res_upd;

   
   
   function inserir_alu()
   {
	  include("../Modelo/sql_insert_aluno.php");
	  $this->ins = mysql_query($this->sql_ins);
	  $_SESSION["msg"] = "<font color='#0066FF'>"."Aluno INSERIDO com sucesso!"."</font>"; //Mensagem exibição para a pagina 
      print "<meta HTTP-EQUIV='Refresh' CONTENT='0;URL=../Visao/index.php?active2=active&page=1&fun=7'>";
   }
   
   function selecionar_alu()
   {
   
   }
   
   function alterar_alu()
   {
	include("../Modelo/sql_update_aluno.php"); 
    $this->upd = mysql_query($this->sql_upd) or die('Erro:' . mysql_error());
	$_SESSION["msg"] = "<font color='#0066FF'>"."Aluno ALTERADO com Sucesso!"."</font>"; //Mensagem exibição para a pagina 
    print "<meta HTTP-EQUIV='Refresh' CONTENT='0;URL=../Visao/index.php?active2=active&page=1&fun=7&id_aluno=$recebe_get'>";
   }

   function deletar_alu()
   {
   
   }

}
$add = new add();
//Variável que recebe a id do usuário pelo _POST do form, que recebe através do primeiro $recebe_get que é igual a _GET da url 
$recebe_post = $_POST["t_id_aluno"];


if($recebe_post <> " "){
 $add->id_aluno      = $_POST["t_id_aluno"];
 $add->nome_alu      = $_POST["t_nome_alu"];
 $add->dt_nas        = datasql($_POST["t_dt_nas"]);
 $add->sexo          = $_POST["t_sexo"];
 $add->cpf           = $_POST["t_cpf"];
 $add->id            = $_POST["t_id"];
 $add->org_exp       = $_POST["t_org_exp"];
 $add->resp_nome_alu = $_POST["t_resp_nome_alu"];
 $add->resp_cpf      = $_POST["t_resp_cpf"];
 $add->resp_id       = $_POST["t_resp_id"];
 $add->resp_org_exp  = $_POST["t_resp_org_exp"];
 $add->ende          = $_POST["t_end"];
 $add->bairro        = $_POST["t_bairro"];
 $add->cidade        = $_POST["t_cidade"];
 $add->cep           = $_POST["t_cep"];
 $add->tel           = $_POST["t_tel"];
 $add->cel           = $_POST["t_cel"];
 $add->email         = $_POST["t_email"];
 $add->obs           = $_POST["t_obs"];
 $add->dt_cri        = $_POST["t_dt_cri"];
 $add->mat_alu       = $_POST["t_mat_alu"];
 
 $add->alterar_alu();
 //echo "senha OK";
}
if($recebe_post == ""){
//$add->id_aluno    = $_POST["t_id_aluno"];
 $add->nome_alu      = $_POST["t_nome_alu"];
 $add->dt_nas        = datasql($_POST["t_dt_nas"]);
 $add->sexo          = $_POST["t_sexo"];
 $add->cpf           = $_POST["t_cpf"];
 $add->id            = $_POST["t_id"];
 $add->org_exp       = $_POST["t_org_exp"];
 $add->resp_nome_alu = $_POST["t_resp_nome_alu"];
 $add->resp_cpf      = $_POST["t_resp_cpf"];
 $add->resp_id       = $_POST["t_resp_id"];
 $add->resp_org_exp  = $_POST["t_resp_org_exp"];
 $add->ende          = $_POST["t_end"];
 $add->bairro        = $_POST["t_bairro"];
 $add->cidade        = $_POST["t_cidade"];
 $add->cep           = $_POST["t_cep"];
 $add->tel           = $_POST["t_tel"];
 $add->cel           = $_POST["t_cel"];
 $add->email         = $_POST["t_email"];
 $add->obs           = $_POST["t_obs"];
 $add->dt_cri        = $_POST["t_dt_cri"];
 $add->mat_alu       = $_POST["t_mat_alu"];
$add->inserir_alu();
//echo "inserir OK";
}     



?>