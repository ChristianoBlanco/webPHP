
<?php 
session_start();
include("func_convert_data.php");
include("../Modelo/conn_conect.php"); //Conexão com o banco local ou de Intranet.

class add 
{

var $id_usu, $dt_usu, $nome_usu, $login, $senha, $nivel_ac, $ins, $upd, $del, $sel, $sql_ins, $res_ins, $sql_upd, $res_upd;   
   
   function alterar_usu()
   {
	include("../Modelo/sql_update_usuario.php"); 
    $this->upd = mysql_query($this->sql_upd) or die('Erro:' . mysql_error());
	$_SESSION["msg"] = "<font color='#0066FF'>"."Usuário ALTERADO com Sucesso!"."</font>"; //Mensagem exibição para a pagina 
    print "<meta HTTP-EQUIV='Refresh' CONTENT='0;URL=../Visao/index.php?active1=active&page=0&fun=6'>";
   }

}
$add = new add();
//Variável que recebe a id do usuário pelo _POST do form, que recebe através do primeiro $recebe_get que é igual a _GET da url 
$recebe_post = $_POST["t_id_usu"];

if($_POST["t_senha_usu"] <> $_POST["t_csenha_usu"]){	

   $_SESSION["msg"] = "Senhas não conferem!"; 
   print "<meta HTTP-EQUIV='Refresh' CONTENT='0;URL=../Visao/index.php?active1=active&page=0&fun=6'>";
}else{
if($recebe_post <> " "){
 //Testa senha e confirma senha são iguais
 $add->id_usu    = $_POST["t_id_usu"];
 $add->dt_usu    = datasql($_POST["t_dt_usu"]);
 $add->nome_usu  = $_POST["t_nome_usu"];
 $add->login     = $_POST["t_log_usu"];
 $add->senha     = md5($_POST["t_senha_usu"]);
 $add->nivel_ac  = $_POST["t_nivel_usu"];
 $add->alterar_usu();
 //echo "senha OK";
}  

}

?>