﻿<?php 

function converte_nome($id_conv){

$sql_convert = mysql_query("SELECT id_aluno, nome_alu FROM tb_aluno WHERE id_aluno = '$id_conv'");
$row_convert = mysql_fetch_array($sql_convert);
return $row_convert["nome_alu"];

}
function converte_id($id_conv){

$sql_convert = mysql_query("SELECT id_aluno, nome_alu FROM tb_aluno WHERE nome_alu = '$id_conv'");
$row_convert = mysql_fetch_array($sql_convert);
return $row_convert["id_aluno"];

}

?>
