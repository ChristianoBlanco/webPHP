<?php //session_start(); ?>

<?php 

$page = 0;
if(isset($_GET["page"])){$page = $_GET["page"];}

switch($page){

  case 0: ?>
       <title>InWeb - Admin </title>
  <?php
   //fim case 0
   break;	
   ?>
   <?php
   case 1:
   ?>
   <title>InWeb - Alunos</title>
   <?php
   break; 
   ?>
   <?php
   case 2:
   ?>
   <title>InWeb - Funcionários</title>
   <?php
   break; 
   ?>
   <?php
   case 3:
   ?>
   <title>InWeb - Atividades</title>
   <?php
   break; 
   ?>
    <?php
   case 4:
   ?>
   <title>InWeb - Matrículas</title>
   <?php
   break; 
   ?>


<?php 
//Fim Switch case
}
?>