<?php
$dbHost = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'innweb';
//connect with the database
$db = new mysqli($dbHost,$dbUsername,$dbPassword,$dbName);
//get search term
$searchTerm = $_GET['term'];
//get matched data from skills table
$query = $db->query("SELECT * FROM tb_aluno WHERE nome_alu LIKE '%".$searchTerm."%' ORDER BY nome_alu ASC");
while ($row = $query->fetch_assoc()) {
    $data[] = $row['nome_alu'];
}
//return json data
echo json_encode($data);
?>