<?php
// Inicia sessões
session_start();

// Conexão com o banco de dados
require "../Modelo/conn_conect.php";

//print $_POST["senha"];

// Recupera o login
$login = isset($_POST["login"]) ? addslashes(trim($_POST["login"])) : FALSE;

// Recupera a senha, a criptografando em MD5
$senha = isset($_POST["senha"]) ? md5(trim($_POST["senha"])) : FALSE;

// Usuário não forneceu a senha ou o login
if(!$login || !$senha)
{
$_SESSION["msg"] = "Você deve digitar sua senha e login!";
print "<meta HTTP-EQUIV='Refresh' CONTENT='0;URL=../visao/login.php'>";
exit;
}


/**
* Executa a consulta no banco de dados.
* Caso o número de linhas retornadas seja 1 o login é válido,
* caso 0, inválido.
*/

include("../Modelo/sql_login_usuario.php");

$result_id = @mysql_query($SQL) or die("Erro no banco de dados!");

$total = @mysql_num_rows($result_id);


// Caso o usuário tenha digitado um login válido o número de linhas será 1..
if($total)
{
// Obtém os dados do usuário, para poder verificar a senha e passar os demais dados para a sessão
$dados = @mysql_fetch_array($result_id);

  // Agora verifica a senha
  if(!strcmp($senha, $dados["senha"]))
  {

    // TUDO OK! Agora, passa os dados para a sessão e redireciona o usuário
    $_SESSION["id_usu"]    = $dados["id_usu"];
    $_SESSION["login"]     = stripslashes($dados["login"]);
	$_SESSION["senha"]     = $senha;
    $_SESSION["permissao"] = $dados["nivel_ac"];

    print "<meta HTTP-EQUIV='Refresh' CONTENT='0;URL=../Visao/index.php?active1=active&pag=0'>";
    exit;
  }
  // Senha inválida
  else
  {
   $_SESSION["msg"] = "Senha inválida!";
   print "<meta HTTP-EQUIV='Refresh' CONTENT='0;URL=../visao/login.php'>";
   exit;
  }

}

  // Login inválido
  else
  {
   $_SESSION["msg"] =  "O login fornecido por você é inexistente!";
   print "<meta HTTP-EQUIV='Refresh' CONTENT='0;URL=../visao/login.php'>";
   exit;
  }

?>


