﻿<?php

//Data de vencimento da matrícula
$data_vencimento = databr($row["dt_venc"]);
$novadata = explode("/",$data_vencimento);
	$dia_venc = $novadata[0];
	$mes_venc = $novadata[1];
	$ano_venc = $novadata[2];

$data_atual = date("d/m/Y");
$novadata2 = explode("/",$data_atual);
	$dia_atual = $novadata2[0];
	$mes_atual = $novadata2[1];
	$ano_atual = $novadata2[2];


if ($dia_venc == 0)
	{return date('d/m/Y',mktime(0,0,0,$mes,$dia,$ano));}
	else
	{return date('d/m/Y',mktime(0,0,0,$mes,$dia+$dias,$ano));}
}

?>

<font color="#009900" style="color:#009900; font-size:"/>: