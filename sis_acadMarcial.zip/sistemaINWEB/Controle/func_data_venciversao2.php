﻿<?php 
$data_venc  = $row["dt_venc"];
$data_atual = date("Y-m-d");
//$data_atual = '2017-05-10';

// Comparando as Datas
if(strtotime($data_atual) > strtotime($data_venc))
{	
echo '<font style=color:#F00;font-size:11px;><b>EM DÉBITO :</b></font>';
}
elseif(strtotime($data_atual) == strtotime($data_venc))
{
echo 'Venceu';
}
else
{
echo '<font style=color:#009900;font-size:11px;><b>EM DIA</b></font>';
}
//echo "<br/>"."Cálculos com datas"."<br/>";

//Quantos dias faltam para pagar

if(strtotime($data_atual) <= strtotime($data_venc)){
 $diferenca_c = strtotime($data_atual) - strtotime($data_venc);
 $dias_c = floor($diferenca_c / (60*60*24));
 echo "<font style=font-size:11px;> (<font style=color:#009900;><b>".abs($dias_c)."</b></font> p/ vencer)</font>";
}else{
 

// converte as datas para o formato timestamp
$d1 = strtotime("$data_atual"); 
$d2 = strtotime("$data_venc");

// verifica a diferença em segundos entre as duas datas e divide pelo número de segundos que um dia possui
$dataFinal = ($d2 - $d1) /86400;

// caso a data 2 seja menor que a data 1
if($dataFinal < 0)
$dataFinal = $dataFinal * -1;

echo " <font style=font-size:11px;> <font style=color:#F00;font-size:11px;><b>$dataFinal</B></font> dia(s)</font>";

} 
?>
