<?php

class paginacao
{

  var $pg, $sql, $qtn, $ttpg, $res, $inicio, $tr, $tp, $pc, $limite, $sp ;

  function config_paginacao()
  {
    if(!$this->qtn){
	  $this->qtn = 3;  //Recebe a qtd de elementos na barrade navegação
    }
    if(!$this->ttpg){
	  $this->ttpg = 3; //Qtd de registros por página
    }	 	
    try{ //tratamento se a SQL exite ou se está correta, caso não mostra o erro
	  $this->res  = mysql_query($this->sql);
	  $this->tr = mysql_num_rows($this->res);
      if(!$this->pg){ //se variável pg não for verdadeira a variável pc recebe valor para não ficar nulo
	   $this->pc = 1;
      }else{
 	   $this->pc = $this->pg;
      }
	  $this->inicio = $this->pc - 1;
      $this->inicio = $this->inicio * $this->ttpg;
      $this->tp     = $this->tr / $this->ttpg;	
	  if($this->tp > 1){$this->tp = ceil($this->tp);}else{$this->tp = 1;}
      $this->limite = mysql_query("$this->sql limit $this->inicio, $this->ttpg");
      ?>
      <table width="98%" cellpadding="0" cellspacing="0" id="box-table-a" style="margin-left:10px;">
      <thead>
      <tr>
      <td style="font-weight:bold;">CONSULTAR PAGAMENTOS TRANCADOS</td>
      <form name="form1" action="index.php?" method="get" enctype="multipart/form-data" />
      <td style="font-size:10px;">Pesquisar por: 
      <input type="hidden" name="active2" value="active" />
      <input type="hidden" name="page" value="4" />
      <input type="hidden" name="fun" value="201" />
      
      <select name="t_ord_pesq" required>
      <option value="" selected="selected"></option>
      <option value="id_alu">Nome</option>
      <option value="mat_alu">Matricula</option>
      </select>
      &nbsp;
      <input type="text" name="t_like_pesq" size="20" required />
      <input type="submit" value="ir" />
      </form>
      </td>
      <!-- form name="form2" action="index.php?" method="get" enctype="multipart/form-data" -->
      <td style="font-size:10px;"> 
      <?php $dt_atual = date("Y-m-d");	 ?>
      <!-- select name="t_ord" onchange="location.href='index.php?active2=active&page=4&fun=201&t_ord='+this.value" required >
      <option value="" selected="selected"></option>
      <option value="WHERE status_pg='A' and CURDATE() < date(dt_venc) ORDER BY id_alu asc">Em dia</option>
      <option value="WHERE status_pg='A' and CURDATE() = date(dt_venc) ORDER BY id_alu asc">Vencido</option>
      <option value="WHERE status_pg='A' and CURDATE() > date(dt_venc) ORDER BY id_alu asc">Em Débito</option> 
      </select -->
      </td>
      <!--/form -->
      </tr>
      </thead>
      </table>
      <br />
      <table width="98%" cellpadding="0" cellspacing="0" id="box-table-a" class="table table-striped table-bordered" style="margin-left:10px;">
      <thead>
       <tr>
        <th width="19%"  scope="col"><?php  print ("Matricula"); ?></th>
        <th width="34%" scope="col"><div style="margin-left:0px;"><?php  print("Aluno"); ?></div></th>
        <th width="17%" scope="col" ><div style="margin-left:0px;"><?php print ("Data vencimento"); ?></div></th>
        <th width="17%" scope="col" ><?php print ("Situação"); ?></th>
        <th width="13%" scope="col" ><a href="http://localhost/web/sistemaINWEB/Visao/index.php?active1=active&page=0&fun=0" target="_parent"><div style="margin-left:35px;"><img src="../Visao/images/buttons/Sair_over.png" width="26" height="26" title="Sair"></div></div></th>
       </tr>
       </tr>
      </thead>
      <tbody>
      <?php
      //Mostra resultados
	  include("func_convert_id_aluno.php");
      while($row = mysql_fetch_array($this->limite)){
      ?>
      <tr>
       <td width="19%"><?php print $row["mat_alu"]; ?></td>
       <td width="34%"><?php print converte_nome($row["id_alu"]); ?></td>
       <td width="17%"><?php print databr($row["dt_venc"]); ?></td>
       <td width="17%">
	   <?php  
	   echo "Trancado";
	   ?>
       </td>
       <td width="13%" align="center">
       <a href="index.php?active1=active&page=4&fun=21&id_aluno=<?php print $row["id_alu"]; ?>"><img src="../Visao/images/buttons/Edit_over.png" width="17" height="17" title="Editar/Consultar Dados"></a>&nbsp;&nbsp;|&nbsp;&nbsp;
       <a href="index.php?active1=active&page=1&fun=8&nome_usu=<?php print $row["nome_alu"]; ?>&id_usu=<?php echo $row["id_aluno"]; ?>" onclick="return confirm('Deseja excluir <?php print utf8_encode($row["nome_alu"]); ?> ?')"><img src="../Visao/images/buttons/Delete_over.png" width="14" height="14" title="Apagar dados"></a>
       </td>
      </tr>
      <?php 
       }
      ?>
      </tbody>	
      </table>

      <?php
       #	AQUI COMEÇA A BARRA DE NAVEGAÇÃO
      print "<table width='50%' style='margin-left:10px;' id='box-table-a' class='table table-striped table-bordered' >
	       <tr>
		   <td align='center'><p align='center'><font size='1' face='verdana' color='#333333'>";
       if($this->tp > 1)// se existir mais de uma página
	   {
       $prior = $this->pc - 1;// avança pagina
       $next = $this->pc + 1;// regride pagina

       // cria botão primeiro registro
      if($this->pc != 1){print "<a href='index.php?active1=active&page=4&fun=20&t_ord=$_SESSION[ordena]&pg=1'>PRIMEIRA&nbsp;&nbsp;</a>";}else{print "PRIMEIRA&nbsp;&nbsp;";}
        print $this->sp;
      // cria botão anterior
      if($this->pc > 1){print "<a href='index.php?active1=active&page=4&fun=20&t_ord=$_SESSION[ordena]&pg=$prior'>ANTERIOR&nbsp;&nbsp;</a>";}else{print "ANTERIOR&nbsp;&nbsp;";}
        print $this->sp;
      # AQUI COMEÇA A CRIAÇÃO DOS NÚMEROS MIOLOS NA BARRA DE NAVEGAÇÃO
      if($this->tp < $this->qtn)	// verifica se a quantidade de página está abaixo do valor estabelecido
      {		
       $min = 1;
       $max = $this->tp;
      }			// fim do teste do valor
      else
	  {			// faz as alterações necessárias se o valor estiver acima
       $min = $this->pc;
       $max = $this->qtn + $min;
      if($max >= $this->tp)
	  {
       $max = $this->tp;
       $min = $max - $this->qtn;
	  }
	  }			// fim da verificação

      for($cont = $min; $max >= $cont; $cont++)// analisa o resultado da verificação
	  {
      // mostra o resultado
      if($cont <> $this->pc){print "<a href='index.php?active1=active&page=4&fun=20&t_ord=$_SESSION[ordena]&pg=$cont'>$cont&nbsp;&nbsp;</a>".$this->sp;}else{print "<b>$cont</b>$this->sp&nbsp;&nbsp;";}
	  }
	  // fim da análise

      // cria botão proximo
      if($this->pc < $this->tp){print ("<a href='index.php?active1=active&page=4&fun=20&t_ord=$_SESSION[ordena]&pg=$next'>PRÓXIMA&nbsp;&nbsp;</a>");}else{print (  "PRÓXIMA&nbsp;&nbsp;");}
       print $this->sp;
      // cria botão último
      if($this->pc != $this->tp){print ("<a href='index.php?active1=active&page=4&fun=20&t_ord=$_SESSION[ordena]&pg=$this->tp'>ÚLTIMA&nbsp;&nbsp;</a>");}else{print ("ÚLTIMA&nbsp;&nbsp;");}
	  }

      // se o houver uma página só, imprime a barra desativada
      if(!$this->tp)
	  {
       print "PRIMEIRA | ANTERIOR | PRÓXIMA |ÚLTIMA";
      }
      // fim da barra desativada
	
      print "</p><br></td></tr></table>";
      # FIM DA BARRA DE NAVEGAÇÃO
?>   
<?php	  
	  
	}
    catch(Exception $e){
	  echo "exeção1: ", $e->getMessage(), "\n";//msg de erro caso SQL tenha erro	 
    }
	
  }
    
}

?>