﻿<?php
$ano = date("y");
$mes = date("n");
$dia = date("j");
$randon = mt_rand(5, 99);
$geraMat = "$ano" . "$mes"."-" . "$dia". "$randon";
//print $geraMat;
?>
