<?php

class se_existe {

var $conf, $sql_conf, $res_conf;

   function se_existe_usu()
   {
	 //Query executada da pasta Model contendo a SQL que receberá o $_GET para saber se existe o campo ID da tabela referente
	 $this->conf = mysql_query($this->sql_conf);
	 $this->res_conf = mysql_fetch_array($this->conf);
   }


   function se_existe_alu()
   {
	 //Query executada da pasta Model contendo a SQL que receberá o $_GET para saber se existe o campo ID da tabela referente
	 $this->conf = mysql_query($this->sql_conf);
	 $this->res_conf = mysql_fetch_array($this->conf);
   }
   function se_existe_func()
   {
	 //Query executada da pasta Model contendo a SQL que receberá o $_GET para saber se existe o campo ID da tabela referente
	 $this->conf = mysql_query($this->sql_conf);
	 $this->res_conf = mysql_fetch_array($this->conf);
   }
   function se_existe_ativ()
   {
	 //Query executada da pasta Model contendo a SQL que receberá o $_GET para saber se existe o campo ID da tabela referente
	 $this->conf = mysql_query($this->sql_conf);
	 $this->res_conf = mysql_fetch_array($this->conf);
   }
   function se_existe_ativ_gd()
   {
	 //Query executada da pasta Model contendo a SQL que receberá o $_GET para saber se existe o campo ID da tabela referente
	 $this->conf = mysql_query($this->sql_conf);
	 $this->res_conf = mysql_fetch_array($this->conf);
   }
   function se_existe_matricula()
   {
	 //Query executada da pasta Model contendo a SQL que receberá o $_GET para saber se existe o campo ID da tabela referente
	 $this->conf = mysql_query($this->sql_conf);
	 $this->res_conf = mysql_fetch_array($this->conf);
   }
}
?>