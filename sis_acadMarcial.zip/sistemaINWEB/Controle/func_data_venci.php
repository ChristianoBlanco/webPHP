﻿<?php

function CalcularVencimento($data,$dias)
{
	$novadata = explode("/",$data);
	$dia = $novadata[0];
	$mes = $novadata[1];
	$ano = $novadata[2];
	//PARA DESCOBRIR QUAL DATA SERÁ DAQUI A 5 DIAS
	//echo date('d/m/Y',mktime(0,0,0,$mes,$dia+5,$ano));
	//PARA DESCOBRIR QUAL SERÁ O DIA AMANHÃ
	//echo date('d/m/Y',mktime(0,0,0,$mes,$dia+1,$ano));
	//PARA MÊS QUE VEM
	//echo date('d/m/Y',mktime(0,0,0,$mes + 1,$dia,$ano));
	//PARA ANO QUE VEM
	//echo date('d/m/Y',mktime(0,0,0,$mes,$dia,$ano + 1));
	if ($dias==0)
	{return date('d/m/Y',mktime(0,0,0,$mes,$dia,$ano));}
	else
	{return date('d/m/Y',mktime(0,0,0,$mes,$dia+$dias,$ano));}
}

//$data ="06/02/2017";
//$dias = "30";

//print CalcularVencimento($data,$dias);


?>