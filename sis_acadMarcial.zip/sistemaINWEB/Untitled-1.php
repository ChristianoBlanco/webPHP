<?php 

class add 
{

var $nome, $login, $senha, $nivel, $ins, $upd, $del, $sel, $conf, $sql_ins, $sql_conf, $res_ins;

   function se_existe_usu()
   {
	   
   }
   
   function inserir_usu()
   {
	  $this->ins = mysql_query($this->sql_ins);
	  $_SESSION["msg"] = "<font color='#0066FF'>"."DADOS INSERIDO com sucesso!"."</font>"; //Mensagem exibição para a pagina 
      print "<meta HTTP-EQUIV='Refresh' CONTENT='0;URL=index.php?active1=active&page=0&fun=3'>";
   }
   
   function selecionar_usu()
   {
   
   }
   
   function alterar_usu()
   {
   
   }

   function deletar_usu()
   {
   
   }

}

?>