<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<form>
<table width="500" border="0" cellspacing="2" cellpadding="0">
<input type="hidden" name="t_dt_usu" value="<?php echo date("d/m/Y"); ?>" size="10" maxlength="11" />  
  <tr>
    <td align="right">Nome:&nbsp;</td>
    <td><input type="text" name="t_nome_usu" value="" size="60" maxlength="60" required="required" /></td>
  </tr>
  <tr>
    <td align="right">Login:&nbsp;</td>
    <td><input type="text" name="t_log_usu" value="" size="30" maxlength="30" required="required" /></td>
  </tr>
  <tr>
    <td align="right">Senha:&nbsp;</td>
    <td><input type="password" name="t_senha_usu" value="" size="30" maxlength="30" required="required" /></td>
  </tr>
  <tr>
    <td align="right">Confirma senha:&nbsp;</td>
    <td><input type="password" name="t_csenha_usu" value="" size="30" maxlength="30" required="required" /></td>
  </tr>
  <tr>
    <td align="right">Nivel de acesso:&nbsp;</td>
    <td>
    <select name="t_nivel_usu" required="required">
    <option value=" " selected="selected"></option>
    <option value="3">Administrador</option>
    <option value="2">Super usuário</option>
    <option value="1">Usuário</option>
    <option value="0">Visitante</option>
    </select>
    </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input type="submit" value="Gravar" name="bt_adm_grava" /></td>
  </tr>
</table>


</form>
</body>
</html>